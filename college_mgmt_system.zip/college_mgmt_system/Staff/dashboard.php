<?php
require_once __DIR__.'/../includes/session.php';
require_once __DIR__.'/../includes/db.php';
require_role('staff');

$staff_name = $_SESSION['full_name'];
$staff_id = $_SESSION['user_id'];

// Fetch faculty-specific stats
$assignment_count = $db->prepare("SELECT COUNT(*) FROM assignments WHERE staff_id = ?");
$assignment_count->execute([$staff_id]);
$total_assignments = $assignment_count->fetchColumn();

// $leave_requests = $db->prepare("SELECT COUNT(*) FROM leave_requests WHERE sender_id = ? AND sender_role = 'staff'");
// $leave_requests->execute([$staff_id]);
// $recent_leaves = $leave_requests->fetchColumn();

$feedback_pending = $db->prepare("SELECT COUNT(*) FROM feedback WHERE sender_id = ? AND sender_role = 'staff' AND status = 'Pending'");
$feedback_pending->execute([$staff_id]);
$pending_feedback = $feedback_pending->fetchColumn();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Faculty Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        :root {
            --primary: #4e73df;
            --secondary: #1cc88a;
            --light: #f8f9fc;
        }
        body {
            background-color: var(--light);
        }
        .dashboard-header {
            background: white;
            box-shadow: 0 0.15rem 1.75rem rgba(58, 59, 69, 0.15);
        }
        .card {
            border: none;
            border-radius: 0.35rem;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.1);
            transition: transform 0.3s;
        }
        .card:hover {
            transform: translateY(-5px);
        }
        .card-primary {
            border-left: 0.25rem solid var(--primary);
        }
        .card-success {
            border-left: 0.25rem solid var(--secondary);
        }
        .quick-link {
            transition: all 0.3s;
            width: 100%;
            padding: 12px;
            font-size: 16px;
        }
        .quick-link i {
            font-size: 1.2rem;
        }
        .equal-height {
            display: flex;
            flex-direction: column;
            height: 100%;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg dashboard-header navbar-light mb-4">
    <div class="container-fluid">
        <span class="navbar-brand">
            <i class="bi bi-speedometer2 me-2"></i>
            Faculty Dashboard
        </span>
        <div class="d-flex align-items-center">
            <span class="me-3 d-none d-sm-inline">
                <i class="bi bi-person-circle me-1"></i>
                <?= htmlspecialchars($staff_name) ?>
            </span>
            <a href="../auth/logout.php" class="btn btn-outline-danger">
                <i class="bi bi-box-arrow-right"></i> Logout
            </a>
        </div>
    </div>
</nav>

<div class="container">
    <!-- Stats Cards -->
    <div class="row mb-4">
        <div class="col-md-6 mb-4">
            <div class="card card-primary p-3">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div class="col">
                            <div class="text-xs fw-bold text-primary text-uppercase mb-1">Assigned Assignments</div>
                            <div class="h5 mb-0 fw-bold text-gray-800"><?= $total_assignments ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="bi bi-upload fs-1 text-primary"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- <div class="col-xl-4 col-md-6 mb-4">
            <div class="card card-success h-100 py-2">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col">
                            <div class="text-xs fw-bold text-success text-uppercase mb-1">Recent Leave Requests</div>
                            <div class="h5 mb-0 fw-bold text-gray-800"><?= $recent_leaves ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="bi bi-calendar-check fs-1 text-success"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div> -->

        <div class="col-md-6 mb-4">
            <div class="card card-success p-3">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div class="col">
                            <div class="text-xs fw-bold text-primary text-uppercase mb-1">Pending Feedback</div>
                            <div class="h5 mb-0 fw-bold text-gray-800"><?= $pending_feedback ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="bi bi-chat-left-text fs-1 text-primary"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Quick Links -->
    <div class="row">
        <div class="col-lg-6 mb-4">
            <div class="card shadow equal-height">
                <div class="card-header py-3">
                    <h6 class="m-0 fw-bold text-primary">Academic Functions</h6>
                </div>
                <div class="card-body d-grid gap-3">
                    <a href="mark_attendance.php" class="btn btn-primary quick-link">
                        <i class="bi bi-check2-square me-2"></i> Mark Attendance
                    </a>
                    <a href="results.php" class="btn btn-success quick-link">
                        <i class="bi bi-bar-chart-line me-2"></i> Publish Results
                    </a>
                    <a href="assign_assignment.php" class="btn btn-warning quick-link">
                        <i class="bi bi-upload me-2"></i> Assign Assignments
                    </a>
                </div>
            </div>
        </div>

        <div class="col-lg-6 mb-4">
            <div class="card shadow equal-height">
                <div class="card-header py-3">
                    <h6 class="m-0 fw-bold text-primary">Support & Profile</h6>
                </div>
                <div class="card-body d-grid gap-3">
                    <a href="feedback.php" class="btn btn-info quick-link">
                        <i class="bi bi-chat-left-text me-2"></i> Send Feedback
                    </a>
                    <a href="profile.php" class="btn btn-dark quick-link">
                        <i class="bi bi-person-lines-fill me-2"></i> View Profile
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
