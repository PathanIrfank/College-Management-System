<?php
require_once __DIR__.'/../includes/session.php';
require_once __DIR__.'/../includes/db.php';
require_role('staff');

$staff_id = $_SESSION['user_id'];
$staff_name = $_SESSION['full_name'];
$students = [];
$attendance_saved = false;
$existing_attendance = [];

// Fetch courses and total students
$courses = $db->query("
    SELECT c.id, c.course_name, COUNT(s.id) AS student_count
    FROM courses c
    LEFT JOIN students s ON s.course_id = c.id
    GROUP BY c.id
")->fetchAll(PDO::FETCH_ASSOC);

// Fetch all academic sessions
$sessions = $db->query("SELECT id, name FROM academic_sessions ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);

// Fetch semesters by course
$semester_raw = $db->query("SELECT DISTINCT course_id, semester FROM students")->fetchAll(PDO::FETCH_ASSOC);
$semesters_by_course = [];
foreach ($semester_raw as $row) {
    $semesters_by_course[$row['course_id']][] = $row['semester'];
}

// Fetch all subjects assigned to this staff grouped by course
$staff_subjects_stmt = $db->prepare("
    SELECT s.id AS subject_id, s.subject_name, s.course_id
    FROM subjects s
    JOIN staff_subjects ss ON ss.subject_id = s.id
    WHERE ss.staff_id = ?
");
$staff_subjects_stmt->execute([$staff_id]);
$staff_subjects = $staff_subjects_stmt->fetchAll(PDO::FETCH_ASSOC);
$subjects_by_course = [];
foreach ($staff_subjects as $sub) {
    $subjects_by_course[$sub['course_id']][] = $sub;
}

// Save attendance
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_attendance'])) {
    $course_id = $_POST['course_id'];
    $semester = $_POST['semester'];
    $subject_id = $_POST['subject_id'];
    $session_id = $_POST['session_id'];
    $attendance_date = $_POST['attendance_date'];
    $student_ids = $_POST['student_ids'];

    foreach ($student_ids as $student_id) {
        $status = $_POST["status_$student_id"];

        // Check for existing attendance (based on unique key)
        $check = $db->prepare("SELECT id FROM attendance WHERE student_id = ? AND subject_id = ? AND date = ?");
        $check->execute([$student_id, $subject_id, $attendance_date]);
        $existing = $check->fetchColumn();

        if ($existing) {
            $update = $db->prepare("UPDATE attendance SET status = ?, session_id = ?, recorded_by = ? WHERE id = ?");
            $update->execute([$status, $session_id, $staff_id, $existing]);
        } else {
            $insert = $db->prepare("INSERT INTO attendance (student_id, subject_id, session_id, date, status, recorded_by) VALUES (?, ?, ?, ?, ?, ?)");
            $insert->execute([$student_id, $subject_id, $session_id, $attendance_date, $status, $staff_id]);
        }
    }

    $attendance_saved = true;
}

// Load students and existing attendance
if ($_SERVER['REQUEST_METHOD'] === 'POST' && (isset($_POST['load_students']) || isset($_POST['save_attendance']))) {
    $course_id = $_POST['course_id'];
    $semester = $_POST['semester'];
    $subject_id = $_POST['subject_id'];
    $attendance_date = $_POST['attendance_date'];

    $stmt = $db->prepare("SELECT id, full_name, email FROM students WHERE course_id = ? AND semester = ?");
    $stmt->execute([$course_id, $semester]);
    $students = $stmt->fetchAll();

    $session_id = $_POST['session_id'];
    $stmt = $db->prepare("SELECT student_id, status FROM attendance WHERE subject_id = ? AND session_id = ? AND date = ?");
    $stmt->execute([$subject_id, $session_id, $attendance_date]);

    foreach ($stmt->fetchAll() as $row) {
        $existing_attendance[$row['student_id']] = $row['status'];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Mark Attendance</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        :root { --primary: #4e73df; --light: #f8f9fc; }
        body { background-color: var(--light); }
        .dashboard-header { background: white; box-shadow: 0 0.15rem 1.75rem rgba(0,0,0,0.15); }
        .card { border: none; border-radius: 0.35rem; box-shadow: 0 0.15rem 1.75rem rgba(0,0,0,0.1); }
        .card:hover { transform: translateY(-5px); }
        .card-primary { border-left: 0.25rem solid var(--primary); }
        .quick-link:hover { transform: scale(1.05); box-shadow: 0 0.5rem 1rem rgba(0,0,0,0.15); }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg dashboard-header navbar-light mb-4">
    <div class="container-fluid">
        <span class="navbar-brand"><i class="bi bi-journal-check me-2"></i>Mark Attendance</span>
        <div class="d-flex align-items-center">
            <a href="dashboard.php" class="btn btn-outline-primary me-2">
                    <i class="bi bi-arrow-left"></i> Back to Dashboard
            </a>
            <span class="me-3 d-none d-sm-inline"><i class="bi bi-person-circle me-1"></i><?= htmlspecialchars($staff_name) ?></span>
        </div>
    </div>
</nav>

<div class="container">
    <?php if ($attendance_saved): ?>
        <div class="alert alert-success">Attendance saved successfully!</div>
    <?php endif; ?>

    <!-- Selection Form -->
    <div class="card shadow mb-4">
        <div class="card-header bg-primary text-white">
            <i class="bi bi-funnel me-2"></i>Select Course, Semester, Subject, Session & Date
        </div>
        <div class="card-body">
            <form method="POST" id="filterForm">
                <div class="row g-3">
                    <div class="col-md-3">
                        <label class="form-label">Course</label>
                        <select name="course_id" id="courseSelect" class="form-select" required>
                            <option value="">-- Select Course --</option>
                            <?php foreach ($courses as $course): ?>
                                <option value="<?= $course['id'] ?>" <?= ($_POST['course_id'] ?? '') == $course['id'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($course['course_name']) ?> (<?= $course['student_count'] ?> students)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">Semester</label>
                        <select name="semester" id="semesterSelect" class="form-select" required>
                            <option value="">-- Select --</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Subject</label>
                        <select name="subject_id" id="subjectSelect" class="form-select" required>
                            <option value="">-- Select Subject --</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">Session</label>
                        <select name="session_id" class="form-select" required>
                            <option value="">-- Select --</option>
                            <?php foreach ($sessions as $s): ?>
                                <option value="<?= $s['id'] ?>" <?= ($_POST['session_id'] ?? '') == $s['id'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($s['name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">Date</label>
                        <input type="date" name="attendance_date" class="form-control" value="<?= $_POST['attendance_date'] ?? date('Y-m-d') ?>" required>
                    </div>
                </div>
                <div class="mt-3">
                    <button name="load_students" class="btn btn-success"><i class="bi bi-search"></i> Load Students</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Attendance Table -->
    <?php if (!empty($students)): ?>
        <form method="POST">
            <?php foreach (['course_id', 'semester', 'subject_id', 'session_id', 'attendance_date'] as $field): ?>
                <input type="hidden" name="<?= $field ?>" value="<?= htmlspecialchars($_POST[$field]) ?>">
            <?php endforeach; ?>
            <input type="hidden" name="save_attendance" value="1">

            <div class="card shadow">
                <div class="card-header bg-primary text-white">
                    <i class="bi bi-list-check me-2"></i>Mark / Edit Attendance
                </div>
                <div class="card-body table-responsive">
                    <table class="table table-bordered">
                        <thead class="table-light">
                            <tr>
                                <th>Student Name</th>
                                <th>Email</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($students as $stu): ?>
                                <?php $sid = $stu['id']; ?>
                                <tr>
                                    <td><?= htmlspecialchars($stu['full_name']) ?></td>
                                    <td><?= htmlspecialchars($stu['email']) ?></td>
                                    <td>
                                        <input type="hidden" name="student_ids[]" value="<?= $sid ?>">
                                        <select name="status_<?= $sid ?>" class="form-select" required>
                                            <option value="">-- Select --</option>
                                            <option value="Present" <?= ($existing_attendance[$sid] ?? '') === 'Present' ? 'selected' : '' ?>>Present</option>
                                            <option value="Absent" <?= ($existing_attendance[$sid] ?? '') === 'Absent' ? 'selected' : '' ?>>Absent</option>
                                        </select>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    <div class="mt-3 text-end">
                        <button type="submit" class="btn btn-primary"><i class="bi bi-save me-1"></i> Save Attendance</button>
                    </div>
                </div>
            </div>
        </form>
    <?php endif; ?>
</div>

<script>
    const semestersByCourse = <?= json_encode($semesters_by_course) ?>;
    const subjectsByCourse = <?= json_encode($subjects_by_course) ?>;

    const courseSelect = document.getElementById('courseSelect');
    const semesterSelect = document.getElementById('semesterSelect');
    const subjectSelect = document.getElementById('subjectSelect');

    function updateSemesters(courseId) {
        semesterSelect.innerHTML = '<option value="">-- Select --</option>';
        if (semestersByCourse[courseId]) {
            semestersByCourse[courseId].forEach(sem => {
                const option = document.createElement('option');
                option.value = sem;
                option.textContent = 'Semester ' + sem;
                semesterSelect.appendChild(option);
            });
            <?php if (isset($_POST['semester'])): ?>
            semesterSelect.value = <?= (int)$_POST['semester'] ?>;
            <?php endif; ?>
        }
    }

    function updateSubjects(courseId) {
        subjectSelect.innerHTML = '<option value="">-- Select Subject --</option>';
        if (subjectsByCourse[courseId]) {
            subjectsByCourse[courseId].forEach(sub => {
                const option = document.createElement('option');
                option.value = sub.subject_id;
                option.textContent = sub.subject_name;
                subjectSelect.appendChild(option);
            });
            <?php if (isset($_POST['subject_id'])): ?>
            subjectSelect.value = <?= (int)$_POST['subject_id'] ?>;
            <?php endif; ?>
        }
    }

    courseSelect.addEventListener('change', function () {
        updateSemesters(this.value);
        updateSubjects(this.value);
    });

    window.onload = () => {
        if (courseSelect.value) {
            updateSemesters(courseSelect.value);
            updateSubjects(courseSelect.value);
        }
    };
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
