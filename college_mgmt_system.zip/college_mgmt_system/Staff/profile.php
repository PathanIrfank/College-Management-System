<?php
require_once __DIR__.'/../includes/session.php';
require_once __DIR__.'/../includes/db.php';
require_role('staff');

$staff_id = $_SESSION['user_id'];
$success = $error = null;

// Fetch staff profile
$stmt = $db->prepare("SELECT s.*, d.name AS department FROM staff s LEFT JOIN departments d ON s.department_id = d.id WHERE s.id = ?");
$stmt->execute([$staff_id]);
$staff = $stmt->fetch();

// Fetch subjects assigned
$subjects_stmt = $db->prepare("SELECT sub.subject_name FROM subjects sub
    JOIN staff_subjects ss ON ss.subject_id = sub.id
    WHERE ss.staff_id = ?");
$subjects_stmt->execute([$staff_id]);
$subjects = $subjects_stmt->fetchAll(PDO::FETCH_COLUMN);

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $phone = trim($_POST['phone']);
    $gender = $_POST['gender'];

    $db->prepare("UPDATE staff SET phone = ?, gender = ? WHERE id = ?")
        ->execute([$phone, $gender, $staff_id]);
    $success = "Profile updated successfully.";
}

// Handle password change
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    $current = $_POST['current_password'];
    $new = $_POST['new_password'];
    $confirm = $_POST['confirm_password'];

    if (!password_verify($current, $staff['password'])) {
        $error = "Current password is incorrect.";
    } elseif ($new !== $confirm) {
        $error = "New passwords do not match.";
    } else {
        $hashed = password_hash($new, PASSWORD_DEFAULT);
        $db->prepare("UPDATE staff SET password = ? WHERE id = ?")
            ->execute([$hashed, $staff_id]);
        $success = "Password changed successfully.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Profile</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { background-color: #f8f9fc; }
        .dashboard-header { background: white; box-shadow: 0 0.15rem 1.75rem rgba(58,59,69,0.15); }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg dashboard-header navbar-light bg-white mb-4">
    <div class="container-fluid">
        <span class="navbar-brand"><i class="bi bi-person-lines-fill me-2"></i> My Profile</span>
        <div class="d-flex">
            <a href="dashboard.php" class="btn btn-outline-primary me-2"><i class="bi bi-arrow-left"></i> Back to Dashboard</a>
        </div>
    </div>
</nav>

<div class="container">
    <?php if ($success): ?><div class="alert alert-success"><?= $success ?></div><?php endif; ?>
    <?php if ($error): ?><div class="alert alert-danger"><?= $error ?></div><?php endif; ?>

    <div class="row">
        <!-- Left Column -->
        <div class="col-lg-7 mb-4">
            <!-- Profile Info -->
            <div class="card mb-4">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">Profile Information</h5>
                </div>
                <div class="card-body">
                    <p><strong>Full Name:</strong> <?= htmlspecialchars($staff['full_name']) ?></p>
                    <p><strong>Email:</strong> <?= htmlspecialchars($staff['email']) ?></p>
                    <p><strong>Department:</strong> <?= htmlspecialchars($staff['department']) ?></p>
                    <form method="POST">
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label">Phone</label>
                                <input type="text" name="phone" class="form-control" value="<?= htmlspecialchars($staff['phone']) ?>">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Gender</label>
                                <select name="gender" class="form-select">
                                    <option value="Male" <?= $staff['gender'] == 'Male' ? 'selected' : '' ?>>Male</option>
                                    <option value="Female" <?= $staff['gender'] == 'Female' ? 'selected' : '' ?>>Female</option>
                                    <option value="Other" <?= $staff['gender'] == 'Other' ? 'selected' : '' ?>>Other</option>
                                </select>
                            </div>
                        </div>
                        <button type="submit" name="update_profile" class="btn btn-success"><i class="bi bi-save"></i> Update Profile</button>
                    </form>
                </div>
            </div>

            <!-- Change Password -->
            <div class="card">
                <div class="card-header bg-success text-white">
                    <h5 class="mb-0">Change Password</h5>
                </div>
                <div class="card-body">
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label">Current Password</label>
                            <input type="password" name="current_password" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">New Password</label>
                            <input type="password" name="new_password" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Confirm New Password</label>
                            <input type="password" name="confirm_password" class="form-control" required>
                        </div>
                        <button type="submit" name="change_password" class="btn btn-primary"><i class="bi bi-lock"></i> Change Password</button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Right Column: Assigned Subjects -->
        <div class="col-lg-5 mb-4">
            <div class="card h-100">
                <div class="card-header bg-secondary text-white">
                    <h5 class="mb-0"><i class="bi bi-journal-text me-2"></i> Assigned Subjects</h5>
                </div>
                <div class="card-body">
                    <?php if ($subjects): ?>
                        <ul class="list-group">
                            <?php foreach ($subjects as $sub): ?>
                                <li class="list-group-item"><?= htmlspecialchars($sub) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    <?php else: ?>
                        <p class="text-muted">No subjects assigned.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
