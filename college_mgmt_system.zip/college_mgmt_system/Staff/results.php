<?php
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/db.php';
require_role('staff');

$staff_id = $_SESSION['user_id'];
$staff_name = $_SESSION['full_name'];
$success = null;
$error = null;

// Handle delete
if (isset($_GET['delete_result'])) {
    $result_id = (int)$_GET['delete_result'];
    $stmt = $db->prepare("DELETE FROM results WHERE id = ? AND published_by = ?");
    $stmt->execute([$result_id, $staff_id]);
    $success = "Result deleted successfully.";
}

// Fetch courses taught by the staff
$courses_stmt = $db->prepare("SELECT DISTINCT c.id, c.course_name FROM courses c
    JOIN subjects s ON c.id = s.course_id
    JOIN staff_subjects ss ON ss.subject_id = s.id
    WHERE ss.staff_id = ?");
$courses_stmt->execute([$staff_id]);
$courses = $courses_stmt->fetchAll();

$students = $subjects = $existing_results = [];
$selected_course = $_GET['course_id'] ?? null;
$selected_semester = $_GET['semester'] ?? null;
$selected_subject = $_GET['subject_id'] ?? null;
$selected_session = $_GET['session_id'] ?? null;

if ($selected_course && $selected_semester) {
    $subjects_stmt = $db->prepare("SELECT s.* FROM subjects s
        JOIN staff_subjects ss ON ss.subject_id = s.id
        WHERE s.course_id = ? AND s.semester = ? AND ss.staff_id = ?");
    $subjects_stmt->execute([$selected_course, $selected_semester, $staff_id]);
    $subjects = $subjects_stmt->fetchAll();

    $students_stmt = $db->prepare("SELECT * FROM students WHERE course_id = ? AND semester = ?");
    $students_stmt->execute([$selected_course, $selected_semester]);
    $students = $students_stmt->fetchAll();
}

// Fetch sessions
$sessions = $db->query("SELECT * FROM academic_sessions ORDER BY year_start DESC")->fetchAll();

// Fetch previously entered results for selected subject/session
if ($selected_subject && $selected_session) {
    $results_stmt = $db->prepare("SELECT r.*, s.full_name, s.email FROM results r
        JOIN students s ON s.id = r.student_id
        WHERE r.subject_id = ? AND r.session_id = ? AND r.published_by = ?");
    $results_stmt->execute([$selected_subject, $selected_session, $staff_id]);
    $existing_results = $results_stmt->fetchAll();
}

// Handle result submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_results'])) {
    $subject_id = (int)$_POST['subject_id'];
    $session_id = (int)$_POST['session_id'];
    $entries = $_POST['results'] ?? [];

    foreach ($entries as $student_id => $data) {
        $marks = $data['marks'] ?? null;
        $grade = $data['grade'] ?? null;

        $check = $db->prepare("SELECT id FROM results WHERE student_id = ? AND subject_id = ? AND session_id = ?");
        $check->execute([$student_id, $subject_id, $session_id]);
        if ($check->fetch()) {
            continue; // Skip if result already exists
        }

        if ($marks !== null && $grade !== null) {
            $stmt = $db->prepare("INSERT INTO results (student_id, subject_id, session_id, marks, grade, published_by)
                VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([$student_id, $subject_id, $session_id, $marks, $grade, $staff_id]);
        }
    }

    $success = "Results saved successfully.";
    header("Location: results.php?course_id=$selected_course&semester=$selected_semester&subject_id=$subject_id&session_id=$session_id");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Publish Results</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        :root { --primary: #4e73df; --light: #f8f9fc; }
        body { background-color: var(--light); }
        .dashboard-header { background: white; box-shadow: 0 0.15rem 1.75rem rgba(58, 59, 69, 0.15); }
        .card { border: none; box-shadow: 0 0.15rem 1.75rem rgba(58,59,69,0.1); }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg dashboard-header navbar-light bg-white shadow-sm mb-4">
    <div class="container-fluid">
        <span class="navbar-brand"><i class="bi bi-bar-chart-line me-2"></i> Publish Results</span>
        <div class="d-flex align-items-center">
            <a href="dashboard.php" class="btn btn-outline-primary me-2"><i class="bi bi-arrow-left"></i> Back to Dashboard</a>
            <span class="me-3 d-none d-sm-inline">
                    <i class="bi bi-person-circle me-1"></i> <?= htmlspecialchars($staff_name) ?>
            </span>
        </div>
    </div>
</nav>
<div class="container mb-4">
    <?php if ($success): ?><div class="alert alert-success"><?= $success ?></div><?php endif; ?>
    <?php if ($error): ?><div class="alert alert-danger"><?= $error ?></div><?php endif; ?>

    <!-- Step 1: Course & Semester -->
    <form method="GET" class="card p-3 mb-4">
        <div class="row g-3">
            <div class="col-md-4">
                <label class="form-label">Course</label>
                <select name="course_id" class="form-select" required>
                    <option value="">Select</option>
                    <?php foreach ($courses as $c): ?>
                        <option value="<?= $c['id'] ?>" <?= $selected_course == $c['id'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($c['course_name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label">Semester</label>
                <input type="number" name="semester" min="1" class="form-control" value="<?= htmlspecialchars($selected_semester) ?>" required>
            </div>
            <div class="col-md-2 align-self-end">
                <button class="btn btn-primary w-100"><i class="bi bi-filter me-1"></i> Continue</button>
            </div>
        </div>
    </form>

    <?php if ($selected_course && $selected_semester && $subjects): ?>
        <!-- Step 2: Subject & Session -->
        <form method="GET" class="card p-3 mb-4">
            <input type="hidden" name="course_id" value="<?= $selected_course ?>">
            <input type="hidden" name="semester" value="<?= $selected_semester ?>">
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">Select Subject</label>
                    <select name="subject_id" class="form-select" required>
                        <option value="">-- Select Subject --</option>
                        <?php foreach ($subjects as $s): ?>
                            <option value="<?= $s['id'] ?>" <?= $selected_subject == $s['id'] ? 'selected' : '' ?>><?= htmlspecialchars($s['subject_name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Academic Session</label>
                    <select name="session_id" class="form-select" required>
                        <option value="">-- Select Session --</option>
                        <?php foreach ($sessions as $session): ?>
                            <option value="<?= $session['id'] ?>" <?= $selected_session == $session['id'] ? 'selected' : '' ?>><?= htmlspecialchars($session['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2 align-self-end">
                    <button class="btn btn-success w-100"><i class="bi bi-check-circle me-1"></i> Load</button>
                </div>
            </div>
        </form>
    <?php endif; ?>

    <!-- Result Entry Form -->
    <?php if (!empty($students) && $selected_subject && $selected_session): ?>
        <form method="POST" class="card p-4">
            <input type="hidden" name="subject_id" value="<?= $selected_subject ?>">
            <input type="hidden" name="session_id" value="<?= $selected_session ?>">

            <div class="table-responsive">
                <table class="table table-bordered table-striped">
                    <thead class="table-light">
                        <tr>
                            <th>Student</th>
                            <th>Email</th>
                            <th>Marks</th>
                            <th>Grade</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($students as $stu): ?>
                            <?php
                            $already = $db->prepare("SELECT id FROM results WHERE student_id = ? AND subject_id = ? AND session_id = ?");
                            $already->execute([$stu['id'], $selected_subject, $selected_session]);
                            if ($already->fetch()) continue;
                            ?>
                            <tr>
                                <td><?= htmlspecialchars($stu['full_name']) ?></td>
                                <td><?= htmlspecialchars($stu['email']) ?></td>
                                <td><input type="number" name="results[<?= $stu['id'] ?>][marks]" step="0.01" class="form-control"></td>
                                <td>
                                    <select name="results[<?= $stu['id'] ?>][grade]" class="form-select">
                                        <option value="">Select</option>
                                        <option value="A+">A+</option>
                                        <option value="A">A</option>
                                        <option value="B+">B+</option>
                                        <option value="B">B</option>
                                        <option value="C">C</option>
                                        <option value="D">D</option>
                                        <option value="F">F</option>
                                    </select>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <button type="submit" name="save_results" class="btn btn-success mt-3">
                <i class="bi bi-save me-1"></i> Save Results
            </button>
        </form>

        <!-- Show Previously Entered -->
        <?php if (!empty($existing_results)): ?>
        <div class="card mt-4">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0"><i class="bi bi-table"></i> Previously Entered Results</h5>
            </div>
            <div class="card-body table-responsive">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Student</th>
                            <th>Email</th>
                            <th>Marks</th>
                            <th>Grade</th>
                            <th>Published</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($existing_results as $res): ?>
                            <tr>
                                <td><?= htmlspecialchars($res['full_name']) ?></td>
                                <td><?= htmlspecialchars($res['email']) ?></td>
                                <td><?= $res['marks'] ?></td>
                                <td><?= $res['grade'] ?></td>
                                <td><?= date('d M Y, h:i A', strtotime($res['published_at'])) ?></td>
                                <td>
                                    <a href="?delete_result=<?= $res['id'] ?>&course_id=<?= $selected_course ?>&semester=<?= $selected_semester ?>&subject_id=<?= $selected_subject ?>&session_id=<?= $selected_session ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this result?')">
                                        <i class="bi bi-trash"></i> Delete
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php endif; ?>
    <?php endif; ?>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
