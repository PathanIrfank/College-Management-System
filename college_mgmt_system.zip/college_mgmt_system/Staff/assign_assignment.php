<?php
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/db.php';
require_role('staff');

$staff_id = $_SESSION['user_id'];
$staff_name = $_SESSION['full_name'];
$success = null;

// Handle delete
if (isset($_GET['delete'])) {
    $id = (int) $_GET['delete'];
    $stmt = $db->prepare("DELETE FROM assignments WHERE id = ? AND staff_id = ?");
    $stmt->execute([$id, $staff_id]);
    header("Location: assign_assignment.php");
    exit;
}

// Handle update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_assignment'])) {
    $id = $_POST['assignment_id'];
    $title = sanitize_input($_POST['title']);
    $description = sanitize_input($_POST['description']);
    $deadline = $_POST['deadline'];

    $updateQuery = "UPDATE assignments SET title = ?, description = ?, deadline = ?";
    $params = [$title, $description, $deadline];

    if (!empty($_FILES['assignment_file']['name'])) {
        $upload_dir = "../uploads/assignments/";
        if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);
        $filename = time() . "_" . basename($_FILES["assignment_file"]["name"]);
        $target_file = $upload_dir . $filename;
        if (move_uploaded_file($_FILES["assignment_file"]["tmp_name"], $target_file)) {
            $file_path = "uploads/assignments/" . $filename;
            $updateQuery .= ", file_path = ?";
            $params[] = $file_path;
        }
    }

    $updateQuery .= " WHERE id = ? AND staff_id = ?";
    $params[] = $id;
    $params[] = $staff_id;

    $stmt = $db->prepare($updateQuery);
    $stmt->execute($params);
    $success = "Assignment updated successfully.";
}

// Handle new assignment
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['assign'])) {
    $subject_id = $_POST['subject_id'];
    $title = sanitize_input($_POST['title']);
    $description = sanitize_input($_POST['description']);
    $deadline = $_POST['deadline'];

    $file_path = null;
    if (!empty($_FILES['assignment_file']['name'])) {
        $upload_dir = "../uploads/assignments/";
        if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);
        $filename = time() . "_" . basename($_FILES["assignment_file"]["name"]);
        $target_file = $upload_dir . $filename;
        if (move_uploaded_file($_FILES["assignment_file"]["tmp_name"], $target_file)) {
            $file_path = "uploads/assignments/" . $filename;
        }
    }

    $stmt = $db->prepare("INSERT INTO assignments (staff_id, subject_id, title, description, file_path, deadline) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->execute([$staff_id, $subject_id, $title, $description, $file_path, $deadline]);
    $success = "Assignment successfully assigned.";
}

// Get assigned subjects
$stmt = $db->prepare("
    SELECT subjects.id, subjects.subject_name, courses.course_name
    FROM staff_subjects
    JOIN subjects ON staff_subjects.subject_id = subjects.id
    JOIN courses ON subjects.course_id = courses.id
    WHERE staff_subjects.staff_id = ?");
$stmt->execute([$staff_id]);
$subjects = $stmt->fetchAll();

// Get previously assigned assignments
$stmt = $db->prepare("
    SELECT a.*, s.subject_name, c.course_name,
        (SELECT COUNT(*) FROM submissions WHERE submissions.assignment_id = a.id) AS submission_count
    FROM assignments a
    JOIN subjects s ON a.subject_id = s.id
    JOIN courses c ON s.course_id = c.id
    WHERE a.staff_id = ?
    ORDER BY a.created_at DESC");
$stmt->execute([$staff_id]);
$previous_assignments = $stmt->fetchAll();

// Fetch submissions for all assignments
$submissions = [];
if (!empty($previous_assignments)) {
    $ids = array_column($previous_assignments, 'id');
    $placeholders = implode(',', array_fill(0, count($ids), '?'));

    $sub_stmt = $db->prepare("
        SELECT submissions.*, students.full_name 
        FROM submissions 
        JOIN students ON submissions.student_id = students.id
        WHERE submissions.assignment_id IN ($placeholders)
    ");
    $sub_stmt->execute($ids);
    foreach ($sub_stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $submissions[$row['assignment_id']][] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Assign Assignment</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
<style>
    body { background-color: #f8f9fc; }
    .dashboard-header { background: white; box-shadow: 0 0.15rem 1.75rem rgba(58, 59, 69, 0.15); }
    .card { border: none; border-radius: 0.35rem; box-shadow: 0 0.15rem 1.75rem rgba(58,59,69,0.1); transition: transform 0.3s; }
    .card.assignment-card:hover { transform: translateY(-5px); }
    .form-control, .form-select { border-radius: 0.3rem; }
    .table thead { background-color: #e3e6f0; }
    .alert-success { background-color: #d1e7dd; border: 1px solid #badbcc; color: #0f5132; border-radius: 0.35rem; }
</style>
</head>
<body>

<nav class="navbar navbar-expand-lg dashboard-header navbar-light mb-4">
    <div class="container-fluid">
        <span class="navbar-brand"><i class="bi bi-upload me-2"></i> Assign Assignment</span>
        <div class="d-flex align-items-center">
            <a href="dashboard.php" class="btn btn-outline-primary me-2"><i class="bi bi-arrow-left"></i> Back to Dashboard</a>
            <span class="me-3 d-none d-sm-inline"><i class="bi bi-person-circle me-1"></i> <?= htmlspecialchars($staff_name) ?></span>
        </div>
    </div>
</nav>

<div class="container mb-4">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card p-4">
                <h4 class="mb-3 text-primary">New Assignment</h4>

                <?php if ($success): ?>
                    <div class="alert alert-success"><?= $success ?></div>
                <?php endif; ?>

                <form method="POST" enctype="multipart/form-data">
                    <div class="mb-3">
                        <label class="form-label">Subject</label>
                        <select name="subject_id" class="form-select" required>
                            <option value="">Select Subject</option>
                            <?php foreach ($subjects as $sub): ?>
                                <option value="<?= $sub['id'] ?>"><?= htmlspecialchars($sub['subject_name']) ?> (<?= htmlspecialchars($sub['course_name']) ?>)</option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Title</label>
                        <input type="text" name="title" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Description</label>
                        <textarea name="description" class="form-control" rows="4"></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Assignment File (optional)</label>
                        <input type="file" name="assignment_file" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Deadline</label>
                        <input type="datetime-local" name="deadline" class="form-control" required>
                    </div>
                    <button type="submit" name="assign" class="btn btn-primary w-100">
                        <i class="bi bi-send-check me-2"></i> Assign Assignment
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>



    <!-- Assignment Table -->
    <div class="card mb-5">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0"><i class="bi bi-clock-history me-2"></i> Assigned Assignments</h5>
        </div>
        <div class="card-body table-responsive">
            <?php if (empty($previous_assignments)): ?>
                <p class="text-muted">No assignments assigned yet.</p>
            <?php else: ?>
                <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>Title</th>
                            <th>Subject</th>
                            <th>Course</th>
                            <th>Deadline</th>
                            <th>Submissions</th>
                            <th>File</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($previous_assignments as $assignment): ?>
                        <tr>
                            <td><?= htmlspecialchars($assignment['title']) ?></td>
                            <td><?= htmlspecialchars($assignment['subject_name']) ?></td>
                            <td><?= htmlspecialchars($assignment['course_name']) ?></td>
                            <td><?= date('d M Y, h:i A', strtotime($assignment['deadline'])) ?></td>
                            <td>
                                <a class="btn btn-sm btn-outline-primary" 
                                    data-bs-toggle="collapse" href="#collapse<?= $assignment['id'] ?>" 
                                    role="button" aria-expanded="false" aria-controls="collapse<?= $assignment['id'] ?>">
                                    <?= $assignment['submission_count'] ?> Submission<?= $assignment['submission_count'] != 1 ? 's' : '' ?>
                                </a>
                            </td>
                            <td>
                                <?php if ($assignment['file_path']): ?>
                                    <a href="../<?= $assignment['file_path'] ?>" target="_blank" class="btn btn-sm btn-outline-info">
                                        <i class="bi bi-file-earmark-arrow-down"></i> View
                                    </a>
                                <?php else: ?>
                                    <span class="text-muted">No file</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#editModal<?= $assignment['id'] ?>">
                                    <i class="bi bi-pencil-square"></i> Edit
                                </button>
                                <a href="?delete=<?= $assignment['id'] ?>" onclick="return confirm('Are you sure?')" 
                                   class="btn btn-sm btn-danger">
                                    <i class="bi bi-trash"></i> Delete
                                </a>
                            </td>
                        </tr>

                        <!-- Submissions List -->
                        <tr class="collapse" id="collapse<?= $assignment['id'] ?>">
                            <td colspan="7">
                                <?php if (!empty($submissions[$assignment['id']])): ?>
                                    <div class="collapse-submissions">
                                        <strong>Submissions:</strong>
                                        <ul class="list-group list-group-flush mt-2">
                                            <?php foreach ($submissions[$assignment['id']] as $sub): ?>
                                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                                    <?= htmlspecialchars($sub['full_name']) ?>
                                                    <span>
                                                        <a href="../<?= htmlspecialchars($sub['file_path']) ?>" target="_blank" class="btn btn-sm btn-outline-success me-2">
                                                            <i class="bi bi-download"></i> View
                                                        </a>
                                                        <?php
                                                            if (strtotime($sub['submitted_at']) > strtotime($assignment['deadline'])) {
                                                                echo '<span class="badge badge-late">Late</span>';
                                                            }
                                                        ?>
                                                    </span>
                                                </li>
                                            <?php endforeach; ?>
                                        </ul>
                                    </div>
                                <?php else: ?>
                                    <span class="text-muted">No submissions yet.</span>
                                <?php endif; ?>
                            </td>
                        </tr>

                        <!-- Edit Modal -->
                        <div class="modal fade" id="editModal<?= $assignment['id'] ?>" tabindex="-1" aria-labelledby="editModalLabel<?= $assignment['id'] ?>" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <form method="POST" enctype="multipart/form-data">
                                        <input type="hidden" name="assignment_id" value="<?= $assignment['id'] ?>">
                                        <div class="modal-header bg-primary text-white">
                                            <h5 class="modal-title" id="editModalLabel<?= $assignment['id'] ?>">Edit Assignment</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <div class="mb-3">
                                                <label class="form-label">Title</label>
                                                <input type="text" name="title" class="form-control" value="<?= htmlspecialchars($assignment['title']) ?>" required>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">Description</label>
                                                <textarea name="description" class="form-control" rows="3"><?= htmlspecialchars($assignment['description']) ?></textarea>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">Assignment File (optional)</label>
                                                <input type="file" name="assignment_file" class="form-control">
                                                <?php if (!empty($assignment['file_path'])): ?>
                                                    <small>Current: <a href="../<?= $assignment['file_path'] ?>" target="_blank">View</a></small>
                                                <?php endif; ?>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">Deadline</label>
                                                <input type="datetime-local" name="deadline" class="form-control" 
                                                    value="<?= date('Y-m-d\TH:i', strtotime($assignment['deadline'])) ?>" required>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                            <button type="submit" name="update_assignment" class="btn btn-primary">Update</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>

                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>