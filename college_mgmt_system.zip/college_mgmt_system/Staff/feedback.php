<?php
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/db.php';
require_role('staff');

$staff_id = $_SESSION['user_id'];
$staff_name = $_SESSION['full_name'];
$success = $error = null;

// Handle feedback submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_feedback'])) {
    $message = trim($_POST['message']);
    if (!empty($message)) {
        $stmt = $db->prepare("INSERT INTO feedback (sender_id, sender_role, message, status) VALUES (?, 'staff', ?, 'Pending')");
        $stmt->execute([$staff_id, $message]);
        $_SESSION['feedback_success'] = "Feedback submitted successfully.";
        header("Location: feedback.php");
        exit;
    } else {
        $error = "Please enter a feedback message.";
    }
}

// Display success message once
if (isset($_SESSION['feedback_success'])) {
    $success = $_SESSION['feedback_success'];
    unset($_SESSION['feedback_success']);
}

// Fetch feedback history for current staff
$stmt = $db->prepare("SELECT * FROM feedback WHERE sender_id = ? AND sender_role = 'staff' ORDER BY created_at DESC");
$stmt->execute([$staff_id]);
$feedbacks = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Staff Feedback</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        :root {
            --primary: #4e73df;
            --light: #f8f9fc;
        }
        body {
            background-color: var(--light);
        }
        .dashboard-header {
            background: white;
            box-shadow: 0 0.15rem 1.75rem rgba(58, 59, 69, 0.15);
        }
        .card {
            border: none;
            box-shadow: 0 0.15rem 1.75rem rgba(58,59,69,0.1);
        }
        .navbar-brand i {
            margin-right: 8px;
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg dashboard-header navbar-light mb-4">
    <div class="container-fluid">
        <span class="navbar-brand d-flex align-items-center">
            <i class="bi bi-chat-left-text fs-5"></i> Send Feedback
        </span>
        <div class="d-flex align-items-center">
                <a href="dashboard.php" class="btn btn-outline-primary me-2">
                    <i class="bi bi-arrow-left"></i> Back to Dashboard
                </a>
                <span class="me-3 d-none d-sm-inline">
                    <i class="bi bi-person-circle me-1"></i> <?= htmlspecialchars($staff_name) ?>
                </span>
            </div>
    </div>
</nav>

<!-- Container -->
<div class="container mb-4">
    <?php if ($success): ?>
        <div class="alert alert-success"><?= $success ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>

    <!-- Feedback Form -->
    <div class="card p-4 mb-4">
        <h5 class="mb-3 text-primary"><i class="bi bi-pencil-square me-2"></i> Write Feedback</h5>
        <form method="POST">
            <div class="mb-3">
                <textarea name="message" class="form-control" rows="4" placeholder="Write your feedback or concerns..." required></textarea>
            </div>
            <button type="submit" name="send_feedback" class="btn btn-success">
                <i class="bi bi-send me-1"></i> Submit Feedback
            </button>
        </form>
    </div>

    <!-- Feedback History -->
    <div class="card">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0"><i class="bi bi-clock-history me-2"></i> Your Feedback History</h5>
        </div>
        <div class="card-body table-responsive">
            <?php if (empty($feedbacks)): ?>
                <p class="text-muted">You haven't sent any feedback yet.</p>
            <?php else: ?>
                <table class="table table-bordered table-striped">
                    <thead class="table-light">
                        <tr>
                            <th>Message</th>
                            <th>Reply</th>
                            <th>Status</th>
                            <th>Sent On</th>
                            <th>Replied On</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($feedbacks as $f): ?>
                            <tr>
                                <td><?= nl2br(htmlspecialchars($f['message'])) ?></td>
                                <td><?= $f['reply'] ? nl2br(htmlspecialchars($f['reply'])) : '<span class="text-muted">--</span>' ?></td>
                                <td>
                                    <span class="badge bg-<?= $f['status'] === 'Replied' ? 'success' : 'warning' ?>">
                                        <?= $f['status'] ?>
                                    </span>
                                </td>
                                <td><?= date('d M Y, h:i A', strtotime($f['created_at'])) ?></td>
                                <td>
                                    <?= $f['replied_at'] ? date('d M Y, h:i A', strtotime($f['replied_at'])) : '<span class="text-muted">--</span>' ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
