<?php
session_start();
require_once __DIR__ . '/../includes/db.php';

// Redirect if already logged in
if (!empty($_SESSION['user_id'])) {
    header("Location: ../{$_SESSION['role']}/dashboard.php");
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = sanitize_input($_POST['email']);
    $password = $_POST['password'];

    // Check all user tables with proper joins
    $queries = [
        'admin' => "SELECT id, name, password FROM admins WHERE email = ? LIMIT 1",
        'staff' => "SELECT s.id, s.full_name as name, s.password, d.name as department 
                   FROM staff s LEFT JOIN departments d ON s.department_id = d.id 
                   WHERE s.email = ? LIMIT 1",
        'student' => "SELECT s.id, s.full_name as name, s.password, s.course_id, s.semester, c.course_name 
              FROM students s 
              JOIN courses c ON s.course_id = c.id 
              WHERE s.email = ? LIMIT 1"

    ];

    foreach ($queries as $role => $sql) {
        $stmt = $db->prepare($sql);
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            // Set session data
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['role'] = $role;
            $_SESSION['full_name'] = $user['name'];

            // Store additional role-specific data
            if ($role === 'staff')
                $_SESSION['department'] = $user['department'];
            if ($role === 'student') {
                $_SESSION['course'] = $user['course_name'];
                $_SESSION['course_id'] = $user['course_id'];  // Add this line
                $_SESSION['semester'] = $user['semester'];    // Add this line
            }

            header("Location: ../" . ucfirst($role) . "/dashboard.php");
            exit;
        }
    }

    $error = "Invalid email or password";
}
?>
<!DOCTYPE html>
<html>

<head>
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<nav class="navbar navbar-expand-lg dashboard-header navbar-light mb-4">
    <div class="container-fluid">
        <span class="navbar-brand">
            <i class="bi bi-speedometer2 me-2"></i>
            Login page
        </span>
        <a href="../index.php" class="btn btn-outline-primary me-2"><i class="bi bi-arrow-left"></i> Back to Home</a>
            </a>
        </div>
    </div>
</nav>

<body class="bg-light">
    <div class="container" style="max-width: 500px; margin-top: 100px;">
        <div class="card shadow">
            <div class="card-body">
                <h3 class="text-center mb-4">College Login</h3>
                <?php if ($error): ?>
                    <div class="alert alert-danger"><?= $error ?></div>
                <?php endif; ?>
                <form method="POST">
                    <div class="mb-3">
                        <label class="form-label">Email</label>
                        <input type="email" name="email" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Password</label>
                        <input type="password" name="password" class="form-control" required>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Login</button>
                </form>
            </div>
        </div>
    </div>
</body>

</html>