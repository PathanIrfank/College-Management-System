<?php
require_once __DIR__.'/../includes/session.php';
require_once __DIR__.'/../includes/db.php';
require_role('admin');

// Handle Add Subject
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_subject'])) {
    $subject_name = sanitize_input($_POST['subject_name']);
    $subject_code = sanitize_input($_POST['subject_code']);
    $course_id = (int)$_POST['course_id'];
    $semester = (int)$_POST['semester'];
    $staff_ids = $_POST['staff_ids'] ?? [];

    $stmt = $db->prepare("INSERT INTO subjects (subject_name, subject_code, course_id, semester) VALUES (?, ?, ?, ?)");
    $stmt->execute([$subject_name, $subject_code, $course_id, $semester]);
    $subject_id = $db->lastInsertId();

    foreach ($staff_ids as $staff_id) {
        $db->prepare("INSERT INTO staff_subjects (staff_id, subject_id) VALUES (?, ?)")->execute([$staff_id, $subject_id]);
    }

    header("Location: manage_subjects.php");
    exit;
}

// Handle Edit Subject
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_subject'])) {
    $id = (int)$_POST['edit_id'];
    $subject_name = sanitize_input($_POST['edit_subject_name']);
    $subject_code = sanitize_input($_POST['edit_subject_code']);
    $course_id = (int)$_POST['edit_course_id'];
    $semester = (int)$_POST['edit_semester'];
    $staff_ids = $_POST['edit_staff_ids'] ?? [];

    $stmt = $db->prepare("UPDATE subjects SET subject_name=?, subject_code=?, course_id=?, semester=? WHERE id=?");
    $stmt->execute([$subject_name, $subject_code, $course_id, $semester, $id]);

    $db->prepare("DELETE FROM staff_subjects WHERE subject_id = ?")->execute([$id]);
    foreach ($staff_ids as $staff_id) {
        $db->prepare("INSERT INTO staff_subjects (staff_id, subject_id) VALUES (?, ?)")->execute([$staff_id, $id]);
    }

    header("Location: manage_subjects.php");
    exit;
}

// Handle Delete Subject
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $db->prepare("DELETE FROM staff_subjects WHERE subject_id = ?")->execute([$id]);
    $db->prepare("DELETE FROM subjects WHERE id = ?")->execute([$id]);
    header("Location: manage_subjects.php");
    exit;
}

// Fetch all subjects with related data
$stmt = $db->query("
    SELECT s.*, c.course_name 
    FROM subjects s 
    JOIN courses c ON s.course_id = c.id 
    ORDER BY s.id DESC
");
$subjects = $stmt->fetchAll();

// Fetch all staff assignments
$staff_assignments = $db->query("SELECT ss.subject_id, st.full_name FROM staff_subjects ss JOIN staff st ON ss.staff_id = st.id")->fetchAll();
$subject_staff_map = [];
foreach ($staff_assignments as $assignment) {
    $subject_staff_map[$assignment['subject_id']][] = $assignment['full_name'];
}

$courses = $db->query("SELECT * FROM courses ORDER BY course_name")->fetchAll();
$staff = $db->query("SELECT id, full_name FROM staff ORDER BY full_name")->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Subjects</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fc;
        }
        .table-responsive {
            overflow-x: auto;
        }
        .action-btns .btn {
            margin-right: 5px;
        }
        .search-box {
            max-width: 300px;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm mb-4">
    <div class="container-fluid">
        <span class="navbar-brand"><i class="bi bi-journal-text me-2"></i> Manage Subjects</span>
        <a href="dashboard.php" class="btn btn-outline-primary">
            <i class="bi bi-arrow-left"></i> Back to Dashboard
        </a>
    </div>
</nav>

<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2><i class="bi bi-journal-text me-2"></i>Subject Management</h2>
        <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#addSubjectModal">
            <i class="bi bi-plus-lg"></i> Add Subject
        </button>
    </div>

    <div class="mb-3">
        <div class="input-group search-box">
            <span class="input-group-text"><i class="bi bi-search"></i></span>
            <input type="text" id="searchSubject" class="form-control" placeholder="Search subjects...">
        </div>
    </div>

    <div class="card shadow">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead class="table-light">
                        <tr>
                            <th>ID</th>
                            <th>Subject Name</th>
                            <th>Subject Code</th>
                            <th>Course</th>
                            <th>Semester</th>
                            <th>Assigned Staff</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="subjectTable">
                        <?php foreach ($subjects as $subject): ?>
                        <tr>
                            <td><?= htmlspecialchars($subject['id']) ?></td>
                            <td><?= htmlspecialchars($subject['subject_name']) ?></td>
                            <td><?= htmlspecialchars($subject['subject_code']) ?></td>
                            <td><?= htmlspecialchars($subject['course_name']) ?></td>
                            <td><?= htmlspecialchars($subject['semester']) ?></td>
                            <td><?= isset($subject_staff_map[$subject['id']]) ? htmlspecialchars(implode(', ', $subject_staff_map[$subject['id']])) : 'Not Assigned' ?></td>
                            <td class="action-btns">
                                <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#editSubjectModal<?= $subject['id'] ?>">
                                    <i class="bi bi-pencil"></i> Edit
                                </button>
                                <a href="?delete=<?= $subject['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure?')">
                                    <i class="bi bi-trash"></i> Delete
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Add Subject Modal -->
<div class="modal fade" id="addSubjectModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <form method="POST" class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title"><i class="bi bi-journal-plus"></i> Add New Subject</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label">Subject Name</label>
                        <input type="text" name="subject_name" class="form-control" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Subject Code</label>
                        <input type="text" name="subject_code" class="form-control" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Course</label>
                        <select name="course_id" class="form-select" required>
                            <option value="">Select Course</option>
                            <?php foreach ($courses as $course): ?>
                            <option value="<?= $course['id'] ?>"><?= htmlspecialchars($course['course_name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Semester</label>
                        <input type="number" name="semester" min="1" class="form-control" required>
                    </div>
                    <div class="col-md-12">
                        <label class="form-label">Assign Staff (Optional)</label>
                        <select name="staff_ids[]" class="form-select" multiple>
                            <?php foreach ($staff as $member): ?>
                            <option value="<?= $member['id'] ?>"><?= htmlspecialchars($member['full_name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" name="add_subject" class="btn btn-primary">Add Subject</button>
            </div>
        </form>
    </div>
</div>

<!-- Edit Modals -->
<?php foreach ($subjects as $subject): ?>
<div class="modal fade" id="editSubjectModal<?= $subject['id'] ?>" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <form method="POST" class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title"><i class="bi bi-pencil"></i> Edit Subject</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <input type="hidden" name="edit_id" value="<?= $subject['id'] ?>">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label">Subject Name</label>
                        <input type="text" name="edit_subject_name" class="form-control" value="<?= htmlspecialchars($subject['subject_name']) ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Subject Code</label>
                        <input type="text" name="edit_subject_code" class="form-control" value="<?= htmlspecialchars($subject['subject_code']) ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Course</label>
                        <select name="edit_course_id" class="form-select" required>
                            <?php foreach ($courses as $course): ?>
                            <option value="<?= $course['id'] ?>" <?= $course['id'] == $subject['course_id'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($course['course_name']) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Semester</label>
                        <input type="number" name="edit_semester" min="1" class="form-control" value="<?= $subject['semester'] ?>" required>
                    </div>
                    <div class="col-md-12">
                        <label class="form-label">Assign Staff</label>
                        <select name="edit_staff_ids[]" class="form-select" multiple>
                            <?php foreach ($staff as $member): ?>
                            <option value="<?= $member['id'] ?>" <?= isset($subject_staff_map[$subject['id']]) && in_array($member['full_name'], $subject_staff_map[$subject['id']]) ? 'selected' : '' ?>>
                                <?= htmlspecialchars($member['full_name']) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" name="edit_subject" class="btn btn-primary">Save Changes</button>
            </div>
        </form>
    </div>
</div>
<?php endforeach; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.getElementById('searchSubject').addEventListener('input', function () {
    const term = this.value.toLowerCase();
    document.querySelectorAll('#subjectTable tr').forEach(row => {
        row.style.display = row.textContent.toLowerCase().includes(term) ? '' : 'none';
    });
});
</script>
</body>
</html>
