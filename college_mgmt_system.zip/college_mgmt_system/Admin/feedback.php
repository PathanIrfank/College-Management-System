<?php
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/db.php';
require_role('admin');

$admin_name = $_SESSION['full_name'];
$admin_id = $_SESSION['user_id'];
$success = null;
$error = null;

// Handle reply
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reply_feedback'])) {
    $feedback_id = (int)$_POST['feedback_id'];
    $reply = trim($_POST['reply']);

    if ($reply !== '') {
        $stmt = $db->prepare("UPDATE feedback SET reply = ?, replied_by = ?, status = 'Replied', replied_at = NOW() WHERE id = ?");
        $stmt->execute([$reply, $admin_id, $feedback_id]);
        $success = "Reply sent successfully.";
    } else {
        $error = "Reply message cannot be empty.";
    }
}

// Filter by role
$role_filter = $_GET['role'] ?? 'all';

$sql = "
    SELECT f.*, 
        CASE 
            WHEN f.sender_role = 'student' THEN (SELECT full_name FROM students WHERE id = f.sender_id)
            WHEN f.sender_role = 'staff' THEN (SELECT full_name FROM staff WHERE id = f.sender_id)
            ELSE 'Unknown'
        END AS sender_name,
        (SELECT name FROM admins WHERE id = f.replied_by) AS admin_name
    FROM feedback f
";
if ($role_filter === 'student' || $role_filter === 'staff') {
    $sql .= " WHERE f.sender_role = " . $db->quote($role_filter);
}
$sql .= " ORDER BY f.created_at DESC";

$feedback_entries = $db->query($sql)->fetchAll();

// Handle delete
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_feedback'])) {
    $feedback_id = (int)$_POST['feedback_id'];
    $stmt = $db->prepare("DELETE FROM feedback WHERE id = ?");
    $stmt->execute([$feedback_id]);
    $success = "Feedback deleted successfully.";
}

// // Fetch feedback
// $stmt = $db->query("SELECT f.*, 
//         CASE 
//             WHEN f.sender_role = 'student' THEN (SELECT full_name FROM students WHERE id = f.sender_id)
//             WHEN f.sender_role = 'staff' THEN (SELECT full_name FROM staff WHERE id = f.sender_id)
//             ELSE 'Unknown'
//         END AS sender_name,
//         (SELECT name FROM admins WHERE id = f.replied_by) AS admin_name
//     FROM feedback f ORDER BY f.created_at DESC");
// $feedback_entries = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Feedback Management</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { background-color: #f8f9fc; }
        .dashboard-header {
            background: white;
            box-shadow: 0 0.15rem 1.75rem rgba(58, 59, 69, 0.15);
        }
        .card {
            border: none;
            box-shadow: 0 0.15rem 1.75rem rgba(58, 59, 69, 0.1);
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg dashboard-header navbar-light mb-4">
    <div class="container-fluid">
        <span class="navbar-brand">
            <i class="bi bi-chat-left-dots me-2"></i> Feedback Management
        </span>
        <div class="d-flex align-items-center">
            <a href="dashboard.php" class="btn btn-outline-primary me-3">
                <i class="bi bi-arrow-left"></i> Back to Dashboard
            </a>
        </div>
    </div>
</nav>


<div class="container">
    <?php if ($success): ?><div class="alert alert-success"><?= $success ?></div><?php endif; ?>
    <?php if ($error): ?><div class="alert alert-danger"><?= $error ?></div><?php endif; ?>


<!-- Filter -->
    <form method="GET" class="mb-3 filter-form">
        <div class="input-group">
            <label class="input-group-text" for="role">Filter by Role</label>
            <select class="form-select" name="role" onchange="this.form.submit()">
                <option value="all" <?= $role_filter === 'all' ? 'selected' : '' ?>>All</option>
                <option value="student" <?= $role_filter === 'student' ? 'selected' : '' ?>>Students</option>
                <option value="staff" <?= $role_filter === 'staff' ? 'selected' : '' ?>>Staff</option>
            </select>
        </div>
    </form>

    <div class="card">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0"><i class="bi bi-chat-text me-2"></i> All Feedback</h5>
        </div>
        <div class="card-body table-responsive">
            <table class="table table-bordered table-striped">
                <thead class="table-light">
                    <tr>
                        <th>Sender</th>
                        <th>Role</th>
                        <th>Message</th>
                        <th>Status</th>
                        <th>Submitted At</th>
                        <th>Reply</th>
                        <th>Replied By</th>
                        <th>Replied At</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($feedback_entries as $entry): ?>
                        <tr>
                            <td><?= htmlspecialchars($entry['sender_name']) ?></td>
                            <td><?= ucfirst($entry['sender_role']) ?></td>
                            <td><?= nl2br(htmlspecialchars($entry['message'])) ?></td>
                            <td>
                                <span class="badge bg-<?= $entry['status'] === 'Replied' ? 'success' : 'warning' ?>">
                                    <?= $entry['status'] ?>
                                </span>
                            </td>
                            <td><?= date('d M Y, h:i A', strtotime($entry['created_at'])) ?></td>
                            <td><?= $entry['reply'] ? nl2br(htmlspecialchars($entry['reply'])) : '—' ?></td>
                            <td><?= $entry['admin_name'] ?? '—' ?></td>
                            <td><?= $entry['replied_at'] ? date('d M Y, h:i A', strtotime($entry['replied_at'])) : '—' ?></td>
                            <td>
                                <?php if ($entry['status'] === 'Pending'): ?>
                                    <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#replyModal<?= $entry['id'] ?>">
                                        <i class="bi bi-reply"></i> Reply
                                    </button>
                                <?php else: ?>
                                    <form method="POST" class="d-inline" onsubmit="return confirmDelete();">
                                        <input type="hidden" name="feedback_id" value="<?= $entry['id'] ?>">
                                        <button type="submit" name="delete_feedback" class="btn btn-sm btn-danger">
                                            <i class="bi bi-trash"></i> Delete
                                        </button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- All Modals Outside Table -->
    <?php foreach ($feedback_entries as $entry): ?>
        <?php if ($entry['status'] === 'Pending'): ?>
            <div class="modal fade" id="replyModal<?= $entry['id'] ?>" tabindex="-1" data-bs-backdrop="static">
                <div class="modal-dialog modal-dialog-centered">
                    <form method="POST" class="modal-content">
                        <input type="hidden" name="feedback_id" value="<?= $entry['id'] ?>">
                        <div class="modal-header bg-primary text-white">
                            <h5 class="modal-title"><i class="bi bi-reply"></i> Reply to Feedback</h5>
                            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <div class="mb-3">
                                <label class="form-label"><strong>Message:</strong></label>
                                <div class="p-2 bg-light border rounded"><?= nl2br(htmlspecialchars($entry['message'])) ?></div>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Your Reply</label>
                                <textarea name="reply" class="form-control" rows="4" required></textarea>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" name="reply_feedback" class="btn btn-success">
                                <i class="bi bi-send-check me-1"></i> Send Reply
                            </button>
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        </div>
                    </form>
                </div>
            </div>
        <?php endif; ?>
    <?php endforeach; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    function confirmDelete() {
        return confirm("Are you sure you want to delete this feedback?");
    }
</script>
</body>
</html>
