<?php
require_once __DIR__.'/../includes/session.php';
require_once __DIR__.'/../includes/db.php';
require_role('admin');

// Handle Add Course
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_course'])) {
    $course_name = sanitize_input($_POST['course_name']);
    $course_code = sanitize_input($_POST['course_code']);
    $duration_years = (int)$_POST['duration_years'];

    $stmt = $db->prepare("INSERT INTO courses (course_name, course_code, duration_years) VALUES (?, ?, ?)");
    $stmt->execute([$course_name, $course_code, $duration_years]);
    header("Location: manage_courses.php");
    exit;
}

// Handle Edit Course
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_course'])) {
    $id = (int)$_POST['edit_id'];
    $course_name = sanitize_input($_POST['edit_course_name']);
    $course_code = sanitize_input($_POST['edit_course_code']);
    $duration_years = (int)$_POST['edit_duration_years'];

    $stmt = $db->prepare("UPDATE courses SET course_name=?, course_code=?, duration_years=? WHERE id=?");
    $stmt->execute([$course_name, $course_code, $duration_years, $id]);
    header("Location: manage_courses.php");
    exit;
}

// Handle Delete Course
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $stmt = $db->prepare("DELETE FROM courses WHERE id = ?");
    $stmt->execute([$id]);
    header("Location: manage_courses.php");
    exit;
}

// Fetch all courses
$courses = $db->query("SELECT * FROM courses ORDER BY id DESC")->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Courses</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        :root {
            --primary: #4e73df;
            --light: #f8f9fc;
        }
        body {
            background-color: var(--light);
        }
        .table-responsive {
            overflow-x: auto;
        }
        .action-btns .btn {
            margin-right: 5px;
        }
        .search-box {
            max-width: 300px;
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm mb-4">
        <div class="container-fluid">
            <span class="navbar-brand">
                <i class="bi bi-journal-bookmark me-2"></i>
                Manage Courses
            </span>
            <a href="dashboard.php" class="btn btn-outline-primary">
                <i class="bi bi-arrow-left"></i> Back to Dashboard
            </a>
        </div>
    </nav>

    <div class="container">
        <!-- Add Course Button -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2><i class="bi bi-journal-bookmark me-2"></i>Course Management</h2>
            <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#addCourseModal">
                <i class="bi bi-plus-lg"></i> Add Course
            </button>
        </div>

        <!-- Search Box -->
        <div class="mb-3">
            <div class="input-group search-box">
                <span class="input-group-text"><i class="bi bi-search"></i></span>
                <input type="text" id="searchCourse" class="form-control" placeholder="Search courses...">
            </div>
        </div>

        <!-- Courses Table -->
        <div class="card shadow">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead class="table-light">
                            <tr>
                                <th>Course Code</th>
                                <th>Course Name</th>
                                <th>Duration (Years)</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="courseTable">
                            <?php foreach ($courses as $course): ?>
                                <tr>
                                    <td><?= htmlspecialchars($course['course_code']) ?></td>
                                    <td><?= htmlspecialchars($course['course_name']) ?></td>
                                    <td><?= htmlspecialchars($course['duration_years']) ?></td>
                                    <td class="action-btns">
                                        <button class="btn btn-sm btn-primary" 
                                                data-bs-toggle="modal" 
                                                data-bs-target="#editCourseModal<?= $course['id'] ?>">
                                            <i class="bi bi-pencil"></i> Edit
                                        </button>
                                        <a href="?delete=<?= $course['id'] ?>" 
                                           class="btn btn-sm btn-danger" 
                                           onclick="return confirm('Are you sure you want to delete this course?')">
                                            <i class="bi bi-trash"></i> Delete
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Add Course Modal -->
    <div class="modal fade" id="addCourseModal" tabindex="-1">
        <div class="modal-dialog">
            <form method="POST" class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title"><i class="bi bi-journal-plus"></i> Add New Course</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Course Code</label>
                        <input type="text" name="course_code" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Course Name</label>
                        <input type="text" name="course_name" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Duration (Years)</label>
                        <input type="number" name="duration_years" class="form-control" min="1" max="10" value="4" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="add_course" class="btn btn-primary">Add Course</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Edit Course Modals -->
    <?php foreach ($courses as $course): ?>
    <div class="modal fade" id="editCourseModal<?= $course['id'] ?>" tabindex="-1">
        <div class="modal-dialog">
            <form method="POST" class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title"><i class="bi bi-pencil"></i> Edit Course</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="edit_id" value="<?= $course['id'] ?>">
                    <div class="mb-3">
                        <label class="form-label">Course Code</label>
                        <input type="text" name="edit_course_code" class="form-control" 
                               value="<?= htmlspecialchars($course['course_code']) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Course Name</label>
                        <input type="text" name="edit_course_name" class="form-control" 
                               value="<?= htmlspecialchars($course['course_name']) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Duration (Years)</label>
                        <input type="number" name="edit_duration_years" class="form-control" 
                               value="<?= htmlspecialchars($course['duration_years']) ?>" min="1" max="10" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="edit_course" class="btn btn-primary">Save Changes</button>
                </div>
            </form>
        </div>
    </div>
    <?php endforeach; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Live search functionality
        document.getElementById('searchCourse').addEventListener('input', function() {
            const searchTerm = this.value.toLowerCase();
            const rows = document.querySelectorAll('#courseTable tr');
            
            rows.forEach(row => {
                const rowText = row.textContent.toLowerCase();
                row.style.display = rowText.includes(searchTerm) ? '' : 'none';
            });
        });
    </script>
</body>
</html>
