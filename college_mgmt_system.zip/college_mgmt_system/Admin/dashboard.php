<?php
require_once __DIR__.'/../includes/session.php';
require_once __DIR__.'/../includes/db.php';
require_role('admin');

// Get admin details and system statistics
$stmt = $db->prepare("
    SELECT a.name, a.email,
    (SELECT COUNT(*) FROM students) AS student_count,
    (SELECT COUNT(*) FROM staff) AS staff_count,
    (SELECT COUNT(*) FROM courses) AS course_count,
    (SELECT COUNT(*) FROM subjects) AS subject_count,
    (SELECT COUNT(*) FROM feedback) AS feedback_count
    FROM admins a WHERE a.id = ?
");
$stmt->execute([$_SESSION['user_id']]);
$admin = $stmt->fetch();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        :root {
            --primary: #4e73df;
            --secondary: #1cc88a;
            --light: #f8f9fc;
        }
        body {
            background-color: var(--light);
        }
        .dashboard-header {
            background: white;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
        }
        .card {
            border: none;
            border-radius: 0.35rem;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.1);
            transition: transform 0.3s;
        }
        .card:hover {
            transform: translateY(-5px);
        }
        .card-primary {
            border-left: 0.25rem solid var(--primary);
        }
        .card-success {
            border-left: 0.25rem solid var(--secondary);
        }
        .quick-link {
            transition: all 0.3s;
        }
        .quick-link:hover {
            transform: scale(1.05);
            box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
        }
        .btn-block {
            width: 100%;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg dashboard-header navbar-light mb-4">
    <div class="container-fluid">
        <span class="navbar-brand">
            <i class="bi bi-speedometer2 me-2"></i>
            Admin Dashboard
        </span>
        <div class="d-flex align-items-center">
            <span class="me-3 d-none d-sm-inline">
                <i class="bi bi-person-circle me-1"></i> <?= htmlspecialchars($admin['name']) ?>
            </span>
            <a href="../auth/logout.php" class="btn btn-outline-danger">
                <i class="bi bi-box-arrow-right"></i> Logout
            </a>
        </div>
    </div>
</nav>

<div class="container">
    <!-- Stats Cards -->
    <div class="row mb-4">
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card card-primary h-100 py-2">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col">
                            <div class="text-xs text-primary text-uppercase mb-1">Students</div>
                            <div class="h5 mb-0 font-weight-bold"><?= $admin['student_count'] ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="bi bi-people-fill fs-1 text-primary"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card card-success h-100 py-2">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col">
                            <div class="text-xs text-success text-uppercase mb-1">Staff</div>
                            <div class="h5 mb-0 font-weight-bold"><?= $admin['staff_count'] ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="bi bi-person-video3 fs-1 text-success"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card card-primary h-100 py-2">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col">
                            <div class="text-xs text-primary text-uppercase mb-1">Courses</div>
                            <div class="h5 mb-0 font-weight-bold"><?= $admin['course_count'] ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="bi bi-journal-bookmark fs-1 text-primary"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card card-success h-100 py-2">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col">
                            <div class="text-xs text-success text-uppercase mb-1">Subjects</div>
                            <div class="h5 mb-0 font-weight-bold"><?= $admin['subject_count'] ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="bi bi-journal-text fs-1 text-success"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Feedback Count Card -->
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card card-primary h-100 py-2">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col">
                            <div class="text-xs text-primary text-uppercase mb-1">Feedbacks</div>
                            <div class="h5 mb-0 font-weight-bold"><?= $admin['feedback_count'] ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="bi bi-chat-left-text fs-1 text-primary"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Quick Links -->
    <div class="row">
        <div class="col-lg-6 mb-4">
            <div class="card shadow h-100">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Student Management</h6>
                </div>
                <div class="card-body d-grid gap-3">
                    <a href="manage_students.php" class="btn btn-primary btn-block quick-link">
                        <i class="bi bi-people-fill me-2"></i>Manage Students
                    </a>
                    <a href="feedback.php" class="btn btn-info btn-block quick-link">
                        <i class="bi bi-chat-left-text me-2"></i>Manage Feedback
                    </a>
                </div>
            </div>
        </div>

        <div class="col-lg-6 mb-4">
            <div class="card shadow h-100">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">System Management</h6>
                </div>
                <div class="card-body d-grid gap-3">
                    <a href="manage_departments.php" class="btn btn-info btn-block quick-link">
                        <i class="bi bi-building me-2"></i>Manage Departments
                    </a>
                    <a href="manage_staff.php" class="btn btn-warning btn-block quick-link">
                        <i class="bi bi-person-video3 me-2"></i>Manage Staff
                    </a>
                    <a href="manage_courses.php" class="btn btn-secondary btn-block quick-link">
                        <i class="bi bi-journal-bookmark me-2"></i>Manage Courses
                    </a>
                    <a href="manage_subjects.php" class="btn btn-dark btn-block quick-link">
                        <i class="bi bi-journal-text me-2"></i>Manage Subjects
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
