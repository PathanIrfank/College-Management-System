<?php
/**
 * Authentication Check File - ERROR-FREE VERSION
 * Location: /college_mgmt_system/includes/auth_check.php
 */

// 1. Require session management FIRST
require_once __DIR__.'/session.php';

// 2. Check if user is logged in
if (!is_logged_in()) {
    header("Location: ../auth/login.php");
    exit;
}

// 3. Define allowed roles and their paths
$allowed_roles = [
    'admin' => '/Admin/',
    'staff' => '/Staff/',
    'student' => '/Student/'
];

// 4. Get current script path safely
$current_path = $_SERVER['SCRIPT_NAME'] ?? '';

// 5. Verify access rights
$allowed = false;
foreach ($allowed_roles as $role => $path) {
    if (strpos($current_path, $path) !== false) {
        if ($_SESSION['role'] === $role) {
            $allowed = true;
        }
        break;
    }
}

// 6. Handle unauthorized access
if (!$allowed) {
    // Log the attempt
    error_log("Unauthorized access attempt by ".($_SESSION['role'] ?? 'unknown')." to $current_path");
    
    // Redirect to appropriate dashboard
    $redirect_path = "../".($_SESSION['role'] ?? 'auth')."/dashboard.php";
    header("Location: $redirect_path");
    exit;
}
?>