<?php
/**
 * Database Connection File - FINAL WORKING VERSION
 * Location: /college_mgmt_system/includes/db.php
 */

// Enable error reporting for debugging (remove in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');          // XAMPP default
define('DB_PASS', '');             // XAMPP default
define('DB_NAME', 'college_mgmt'); // Your database name

try {
    // Create PDO instance with proper error handling
    $db = new PDO(
        "mysql:host=".DB_HOST.";dbname=".DB_NAME.";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
            PDO::ATTR_STRINGIFY_FETCHES => false
        ]
    );
    
    // Verify tables exist (critical check)
    $requiredTables = ['admins', 'staff', 'students', 'courses', 'departments'];
    foreach ($requiredTables as $table) {
        $db->query("SELECT 1 FROM $table LIMIT 1");
    }
    
} catch (PDOException $e) {
    // Handle connection errors gracefully
    $errorMessage = "Database error: " . $e->getMessage();
    error_log($errorMessage);
    
    if (strpos($e->getMessage(), 'Unknown database') !== false) {
        die("Database '".DB_NAME."' doesn't exist. Please create it first.");
    } elseif (strpos($e->getMessage(), 'Base table or view not found') !== false) {
        die("Required tables are missing. Run the installation script.");
    } else {
        die("Connection failed. Check error logs for details.");
    }
}

/**
 * Sanitize input data
 * @param string $data
 * @return string
 */
function sanitize_input($data) {
    return htmlspecialchars(strip_tags(trim($data)), ENT_QUOTES, 'UTF-8');
}

// Initialize session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>