<?php
require_once __DIR__.'/db.php';

$name = "Saud College Admin";
$email = "admin@gmail.com";
$plain_password = "password";
$hashed_password = password_hash($plain_password, PASSWORD_DEFAULT);

try {
    $stmt = $db->prepare("INSERT INTO admins (name, email, password, created_at) VALUES (?, ?, ?, CURRENT_TIMESTAMP)");
    $stmt->execute([$name, $email, $hashed_password]);
    
    echo "Admin created successfully!";
} catch (PDOException $e) {
    echo "Error creating admin: " . $e->getMessage();
}