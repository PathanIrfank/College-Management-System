<?php
// Session config MUST come first
ini_set('session.cookie_httponly', 1);
ini_set('session.use_strict_mode', 1);
ini_set('session.cookie_samesite', 'Strict');
ini_set('session.gc_maxlifetime', 1800); // 30 minutes

if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
    ini_set('session.cookie_secure', 1);
}

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__.'/db.php';

// Session timeout handling
if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > 1800)) {
    session_unset();
    session_destroy();
    header("Location: /college_mgmt_system/auth/login.php?timeout=1");
    exit;
}
$_SESSION['LAST_ACTIVITY'] = time();

function is_logged_in() {
    return isset($_SESSION['user_id'], $_SESSION['role'], $_SESSION['full_name']);
}

function safe_redirect($url) {
    if (!headers_sent()) {
        header("Location: $url");
        exit;
    }
    echo "<script>window.location.href='$url';</script>";
    exit;
}

function require_role($required_role) {
    if (!is_logged_in()) {
        header("Location: ../auth/login.php");
        exit;
    }
    if ($_SESSION['role'] !== $required_role) {
        header("Location: ../{$_SESSION['role']}/dashboard.php");
        exit;
    }
}
?>