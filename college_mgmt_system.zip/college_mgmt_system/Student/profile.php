<?php
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/db.php';
require_role('student');

$student_id = $_SESSION['user_id'];
$success = $error = null;

// Fetch student profile
$stmt = $db->prepare("SELECT s.*, c.course_name 
    FROM students s 
    LEFT JOIN courses c ON s.course_id = c.id 
    WHERE s.id = ?");
$stmt->execute([$student_id]);
$student = $stmt->fetch();

// Fetch enrolled subjects for the student's course and semester
$subjects = [];
if ($student && $student['course_id'] && isset($student['semester'])) {
    $stmt = $db->prepare("SELECT subject_name FROM subjects 
        WHERE course_id = ? AND semester = ?");
    $stmt->execute([$student['course_id'], $student['semester']]);
    $subjects = $stmt->fetchAll(PDO::FETCH_COLUMN);
}



// Handle profile update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $phone = trim($_POST['phone']);
    $gender = $_POST['gender'];

    $db->prepare("UPDATE students SET phone = ?, gender = ? WHERE id = ?")
        ->execute([$phone, $gender, $student_id]);
    $success = "Profile updated successfully.";
}

// Handle password change
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    $current = $_POST['current_password'];
    $new = $_POST['new_password'];
    $confirm = $_POST['confirm_password'];

    if (!password_verify($current, $student['password'])) {
        $error = "Current password is incorrect.";
    } elseif ($new !== $confirm) {
        $error = "New passwords do not match.";
    } else {
        $hashed = password_hash($new, PASSWORD_DEFAULT);
        $db->prepare("UPDATE students SET password = ? WHERE id = ?")
            ->execute([$hashed, $student_id]);
        $success = "Password changed successfully.";
    }
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>My Profile</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fc;
        }

        .dashboard-header {
            background: white;
            box-shadow: 0 0.15rem 1.75rem rgba(58, 59, 69, 0.15);
        }
    </style>
</head>

<body>
    <nav class="navbar navbar-expand-lg dashboard-header navbar-light bg-white mb-4">
        <div class="container-fluid">
            <span class="navbar-brand"><i class="bi bi-person-lines-fill me-2"></i> My Profile</span>
            <div class="d-flex">
                <a href="dashboard.php" class="btn btn-outline-primary me-2"><i class="bi bi-arrow-left"></i> Back to
                    Dashboard</a>
            </div>
        </div>
    </nav>

    <div class="container">
        <?php if ($success): ?>
            <div class="alert alert-success"><?= $success ?></div><?php endif; ?>
        <?php if ($error): ?>
            <div class="alert alert-danger"><?= $error ?></div><?php endif; ?>

        <div class="row">
            <div class="col-lg-8 mb-4">
                <!-- Profile Info -->
                <div class="card mb-4">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0">Profile Information</h5>
                    </div>
                    <div class="card-body">
                        <p><strong>Full Name:</strong> <?= htmlspecialchars($student['full_name']) ?></p>
                        <p><strong>Email:</strong> <?= htmlspecialchars($student['email']) ?></p>
                        <p><strong>Course:</strong> <?= htmlspecialchars($student['course_name']) ?></p>
                        <p><strong>Semester:</strong> <?= htmlspecialchars($student['semester']) ?></p>
                        <form method="POST">
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label class="form-label">Phone</label>
                                    <input type="text" name="phone" class="form-control"
                                        value="<?= htmlspecialchars($student['phone']) ?>">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Gender</label>
                                    <select name="gender" class="form-select">
                                        <option value="Male" <?= $student['gender'] == 'Male' ? 'selected' : '' ?>>Male
                                        </option>
                                        <option value="Female" <?= $student['gender'] == 'Female' ? 'selected' : '' ?>>
                                            Female</option>
                                        <option value="Other" <?= $student['gender'] == 'Other' ? 'selected' : '' ?>>Other
                                        </option>
                                    </select>
                                </div>
                            </div>
                            <button type="submit" name="update_profile" class="btn btn-success"><i
                                    class="bi bi-save"></i> Update Profile</button>
                        </form>
                    </div>
                </div>

                <!-- Change Password -->
                <div class="card">
                    <div class="card-header bg-success text-white">
                        <h5 class="mb-0">Change Password</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <div class="mb-3">
                                <label class="form-label">Current Password</label>
                                <input type="password" name="current_password" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">New Password</label>
                                <input type="password" name="new_password" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Confirm New Password</label>
                                <input type="password" name="confirm_password" class="form-control" required>
                            </div>
                            <button type="submit" name="change_password" class="btn btn-primary"><i
                                    class="bi bi-lock"></i> Change Password</button>
                        </form>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 mb-4">
                <div class="card h-100">
                    <div class="card-header bg-secondary text-white">
                        <h5 class="mb-0"><i class="bi bi-info-circle me-2"></i> Additional Info</h5>
                    </div>
                    <div class="card-body">
                        <?php if (!empty($subjects)): ?>
                            <h4>Enrolled Subjects:</h4>
                            <ul>
                                <?php foreach ($subjects as $subject): ?>
                                    <li><?= htmlspecialchars($subject) ?></li>
                                <?php endforeach; ?>
                            </ul>
                        <?php else: ?>
                            <p>No enrolled subjects found.</p>
                        <?php endif; ?>

                    </div>
                </div>
            </div>
        </div>
    </div>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>