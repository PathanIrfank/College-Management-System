<?php
require_once __DIR__.'/../includes/session.php';
require_once __DIR__.'/../includes/db.php';
require_role('student');

$student_name = $_SESSION['full_name'];
$student_id = $_SESSION['user_id'];
$course_name = $_SESSION['course'];
$course_id = $_SESSION['course_id'];
$semester = $_SESSION['semester'];
$success = null;
$error = null;

// Handle submission upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_assignment'])) {
    $assignment_id = (int)$_POST['assignment_id'];

    if (!empty($_FILES['submission_file']['name'])) {
        $upload_dir = "../uploads/submissions/";
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }
        $filename = time() . "_" . basename($_FILES["submission_file"]["name"]);
        $target_file = $upload_dir . $filename;

        if (move_uploaded_file($_FILES["submission_file"]["tmp_name"], $target_file)) {
            $file_path = "uploads/submissions/" . $filename;

            // Check if already submitted
            $check_stmt = $db->prepare("SELECT id FROM submissions WHERE student_id = ? AND assignment_id = ?");
            $check_stmt->execute([$student_id, $assignment_id]);
            if ($check_stmt->fetch()) {
                $error = "You have already submitted this assignment.";
            } else {
                $stmt = $db->prepare("INSERT INTO submissions (student_id, assignment_id, file_path) VALUES (?, ?, ?)");
                $stmt->execute([$student_id, $assignment_id, $file_path]);
                $success = "Assignment submitted successfully.";
            }
        } else {
            $error = "Failed to upload file.";
        }
    } else {
        $error = "Please select a file to upload.";
    }
}

// Fetch assignments for this student
$stmt = $db->prepare("
    SELECT a.*, s.subject_name
    FROM assignments a
    JOIN subjects s ON a.subject_id = s.id
    WHERE s.course_id = ? AND s.semester = ? AND a.deadline >= NOW()
    ORDER BY a.deadline ASC
");
$stmt->execute([$course_id, $semester]);
$assignments = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch already submitted assignments
$submitted_stmt = $db->prepare("
    SELECT submissions.assignment_id
    FROM submissions
    WHERE submissions.student_id = ?
");
$submitted_stmt->execute([$student_id]);
$submitted_assignments = $submitted_stmt->fetchAll(PDO::FETCH_COLUMN);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Submit Assignment</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        :root {
            --primary: #4e73df;
            --secondary: #1cc88a;
            --light: #f8f9fc;
        }
        body {
            background-color: var(--light);
        }
        .dashboard-header {
            background: white;
            box-shadow: 0 0.15rem 1.75rem rgba(58, 59, 69, 0.15);
        }
        .card {
            border: none;
            border-radius: 0.35rem;
            box-shadow: 0 0.15rem 1.75rem rgba(58, 59, 69, 0.1);
            transition: transform 0.3s;
        }
        .card:hover {
            transform: translateY(-5px);
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg dashboard-header navbar-light mb-4">
    <div class="container-fluid">
        <span class="navbar-brand">
            <i class="bi bi-upload me-2"></i> Submit Assignment
        </span>
        <div class="d-flex align-items-center">
            <a href="dashboard.php" class="btn btn-outline-primary me-2">
                <i class="bi bi-arrow-left"></i> Back to Dashboard
            </a>
            <span class="me-3 d-none d-sm-inline">
                <i class="bi bi-person-circle me-1"></i> <?= htmlspecialchars($student_name) ?>
            </span>
        </div>
    </div>
</nav>

<div class="container mb-5">
    <div class="mb-4 text-center">
        <h4 class="text-primary fw-bold"><?= htmlspecialchars($course_name) ?> - Semester <?= htmlspecialchars($semester) ?></h4>
    </div>

    <?php if ($success): ?>
        <div class="alert alert-success"><?= $success ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>

    <div class="card p-4 mb-4">
        <h5 class="text-primary mb-3"><i class="bi bi-clipboard-data me-2"></i> Available Assignments</h5>

        <?php if (empty($assignments)): ?>
            <p class="text-muted">No active assignments at the moment.</p>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-bordered table-hover align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>Subject</th>
                            <th>Title</th>
                            <th>Deadline</th>
                            <th>File</th>
                            <th>Submission</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($assignments as $assignment): ?>
                            <tr>
                                <td><?= htmlspecialchars($assignment['subject_name']) ?></td>
                                <td><?= htmlspecialchars($assignment['title']) ?></td>
                                <td><span class="badge bg-primary"><?= date('d M Y, h:i A', strtotime($assignment['deadline'])) ?></span></td>
                                <td>
                                    <?php if ($assignment['file_path']): ?>
                                        <a href="../<?= $assignment['file_path'] ?>" target="_blank" class="btn btn-sm btn-info">
                                            <i class="bi bi-file-earmark-arrow-down"></i> View
                                        </a>
                                    <?php else: ?>
                                        <span class="text-muted">No File</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if (in_array($assignment['id'], $submitted_assignments)): ?>
                                        <span class="badge bg-success">Submitted</span>
                                    <?php else: ?>
                                        <form method="POST" enctype="multipart/form-data" class="d-flex gap-2">
                                            <input type="hidden" name="assignment_id" value="<?= $assignment['id'] ?>">
                                            <input type="file" name="submission_file" class="form-control form-control-sm" required>
                                            <button type="submit" name="submit_assignment" class="btn btn-success btn-sm">
                                                <i class="bi bi-upload"></i> Submit
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
