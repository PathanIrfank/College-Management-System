<?php
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/db.php';
require_role('student');

$student_name = $_SESSION['full_name'];
$student_id = $_SESSION['user_id'];
$course_id = $_SESSION['course_id'];
$semester = $_SESSION['semester'];

// Fetch course name
$course_stmt = $db->prepare("SELECT course_name FROM courses WHERE id = ?");
$course_stmt->execute([$course_id]);
$course = $course_stmt->fetchColumn();

// Fetch attendance summary
$summary_stmt = $db->prepare("
    SELECT 
        COUNT(*) AS total_days,
        SUM(CASE WHEN status = 'Present' THEN 1 ELSE 0 END) AS present_days,
        SUM(CASE WHEN status = 'Absent' THEN 1 ELSE 0 END) AS absent_days
    FROM attendance
    WHERE student_id = ?
");
$summary_stmt->execute([$student_id]);
$summary = $summary_stmt->fetch(PDO::FETCH_ASSOC);

// Date filter
$start_date = $_GET['start_date'] ?? null;
$end_date = $_GET['end_date'] ?? null;

$where_clause = "WHERE a.student_id = ?";
$params = [$student_id];

if (!empty($start_date) && !empty($end_date)) {
    $where_clause .= " AND a.date BETWEEN ? AND ?";
    $params[] = $start_date;
    $params[] = $end_date;
}

$attendance_stmt = $db->prepare("
    SELECT a.date, a.status, s.subject_name
    FROM attendance a
    JOIN subjects s ON a.subject_id = s.id
    $where_clause
    ORDER BY a.date DESC
");
$attendance_stmt->execute($params);
$attendance_records = $attendance_stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Attendance</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fc;
        }
        .dashboard-header {
            background: white;
            box-shadow: 0 0.15rem 1.75rem rgba(58,59,69,0.15);
        }
        .card {
            border: none;
            box-shadow: 0 0.15rem 1.75rem rgba(58,59,69,0.1);
            transition: transform 0.3s;
        }
        .card:hover {
            transform: translateY(-5px);
        }
        .highlight-today {
            background-color: #e0f0ff !important;
            font-weight: bold;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg dashboard-header navbar-light mb-4">
    <div class="container-fluid">
        <span class="navbar-brand">
            <i class="bi bi-speedometer2 me-2"></i> Student Panel
        </span>
        <div class="d-flex align-items-center">
            <a href="dashboard.php" class="btn btn-outline-primary me-2">
                <i class="bi bi-arrow-left"></i> Back to Dashboard
            </a>
            <span class="me-3 d-none d-sm-inline">
                <i class="bi bi-person-circle me-1"></i> <?= htmlspecialchars($student_name) ?>
            </span>
        </div>
    </div>
</nav>

<div class="container">
    <div class="row mb-4">
        <div class="col-md-3 mb-3">
            <div class="card text-center p-3">
                <h6 class="text-muted">Total Days</h6>
                <h4><?= $summary['total_days'] ?? 0 ?></h4>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="card text-center p-3">
                <h6 class="text-success">Present</h6>
                <h4><?= $summary['present_days'] ?? 0 ?></h4>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="card text-center p-3">
                <h6 class="text-danger">Absent</h6>
                <h4><?= $summary['absent_days'] ?? 0 ?></h4>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="card text-center p-3">
                <h6 class="text-primary">Attendance %</h6>
                <h4>
                    <?php
                    if ($summary['total_days'] > 0) {
                        $percentage = ($summary['present_days'] / $summary['total_days']) * 100;
                        echo number_format($percentage, 2) . '%';
                    } else {
                        echo 'N/A';
                    }
                    ?>
                </h4>
            </div>
        </div>
    </div>

    <div class="card shadow mb-4">
        <div class="card-header bg-primary text-white">
            <i class="bi bi-calendar-check me-2"></i> Attendance Records
        </div>
        <div class="card-body">
            <p><strong>Course:</strong> <?= htmlspecialchars($course) ?> | <strong>Semester:</strong> <?= htmlspecialchars($semester) ?></p>

            <form method="GET" class="row g-3 align-items-end mb-4">
                <div class="col-md-5">
                    <label class="form-label">Start Date</label>
                    <input type="date" name="start_date" class="form-control" value="<?= htmlspecialchars($start_date) ?>">
                </div>
                <div class="col-md-5">
                    <label class="form-label">End Date</label>
                    <input type="date" name="end_date" class="form-control" value="<?= htmlspecialchars($end_date) ?>">
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="bi bi-funnel-fill me-1"></i> Apply
                    </button>
                </div>
            </form>

            <?php if ($attendance_records): ?>
                <div class="table-responsive">
                    <table class="table table-bordered table-striped align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>Date</th>
                                <th>Subject</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($attendance_records as $record): ?>
                                <?php
                                    $is_today = (date('Y-m-d', strtotime($record['date'])) == date('Y-m-d'));
                                ?>
                                <tr class="<?= $is_today ? 'highlight-today' : '' ?>">
                                    <td><?= date('d M Y', strtotime($record['date'])) ?></td>
                                    <td><?= htmlspecialchars($record['subject_name']) ?></td>
                                    <td>
                                        <?php if ($record['status'] === 'Present'): ?>
                                            <span class="badge bg-success">Present</span>
                                        <?php else: ?>
                                            <span class="badge bg-danger">Absent</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p class="text-muted">No attendance records found.</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
