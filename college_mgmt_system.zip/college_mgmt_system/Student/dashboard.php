<?php
require_once __DIR__.'/../includes/session.php';
require_once __DIR__.'/../includes/db.php';
require_role('student');

$student_name = $_SESSION['full_name'];
$student_id = $_SESSION['user_id'];
$course = $_SESSION['course'];
$semester = $_SESSION['semester'];

// Count total assignments
$assignment_stmt = $db->prepare("SELECT COUNT(*) FROM assignments a
    JOIN subjects s ON s.id = a.subject_id
    JOIN students st ON st.course_id = s.course_id AND st.semester = s.semester
    WHERE st.id = ?");
$assignment_stmt->execute([$student_id]);
$assignment_count = $assignment_stmt->fetchColumn();

// Count pending feedback
$feedback_stmt = $db->prepare("SELECT COUNT(*) FROM feedback WHERE sender_id = ? AND sender_role = 'student' AND status = 'Pending'");
$feedback_stmt->execute([$student_id]);
$pending_feedback = $feedback_stmt->fetchColumn();

// Fetch subjects
$subject_stmt = $db->prepare("SELECT s.subject_name FROM subjects s
    JOIN students st ON s.course_id = st.course_id AND s.semester = st.semester
    WHERE st.id = ?");
$subject_stmt->execute([$student_id]);
$subjects = $subject_stmt->fetchAll(PDO::FETCH_COLUMN);

// Fetch upcoming deadlines
$deadline_stmt = $db->prepare("SELECT a.title, a.deadline FROM assignments a
    JOIN subjects s ON s.id = a.subject_id
    JOIN students st ON st.course_id = s.course_id AND st.semester = s.semester
    WHERE st.id = ? AND a.deadline >= NOW()
    ORDER BY a.deadline ASC LIMIT 5");
$deadline_stmt->execute([$student_id]);
$deadlines = $deadline_stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        :root {
            --primary: #4e73df;
            --secondary: #1cc88a;
            --light: #f8f9fc;
        }
        body {
            background-color: var(--light);
        }
        .dashboard-header {
            background: white;
            box-shadow: 0 0.15rem 1.75rem rgba(58, 59, 69, 0.15);
        }
        .card {
            border: none;
            border-radius: 0.35rem;
            box-shadow: 0 0.15rem 1.75rem rgba(58, 59, 69, 0.1);
            transition: transform 0.3s;
        }
        .card:hover {
            transform: translateY(-5px);
        }
        .card-header {
            font-weight: bold;
        }
        .quick-link {
            transition: all 0.3s;
            width: 100%;
            padding: 12px;
            font-size: 16px;
        }
        .quick-link i {
            font-size: 1.2rem;
        }
        .deadline-date {
            color: #007bff;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg dashboard-header navbar-light mb-4">
    <div class="container-fluid">
        <span class="navbar-brand">
            <i class="bi bi-speedometer2 me-2"></i> Student Dashboard
        </span>
        <div class="d-flex align-items-center">
            <span class="me-3 d-none d-sm-inline">
                <i class="bi bi-person-circle me-1"></i> <?= htmlspecialchars($student_name) ?>
            </span>
            <a href="../auth/logout.php" class="btn btn-outline-danger">
                <i class="bi bi-box-arrow-right"></i> Logout
            </a>
        </div>
    </div>
</nav>

<div class="container">
    <!-- Course and Semester -->
    <div class="mb-4 text-center">
        <h4 class="fw-bold mb-1"><?= htmlspecialchars($course) ?></h4>
        <h5 class="fw-bold text-muted">Semester <?= htmlspecialchars($semester) ?></h5>
    </div>

    <!-- Stats -->
    <div class="row mb-4">
        <div class="col-md-6 mb-4">
            <div class="card card-primary p-3">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <div class="text-uppercase text-primary fw-bold">Assigned Assignments</div>
                        <h4 class="fw-bold"><?= $assignment_count ?></h4>
                    </div>
                    <i class="bi bi-upload fs-1 text-primary"></i>
                </div>
            </div>
        </div>
        <div class="col-md-6 mb-4">
            <div class="card card-success p-3">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <div class="text-uppercase text-success fw-bold">Pending Feedback</div>
                        <h4 class="fw-bold"><?= $pending_feedback ?></h4>
                    </div>
                    <i class="bi bi-chat-left-text fs-1 text-success"></i>
                </div>
            </div>
        </div>
    </div>

    <!-- Row 1: Academic Access (Full width) -->
    <div class="row mb-4">
        <div class="col-lg-12">
            <div class="card h-100 shadow">
                <div class="card-header bg-primary text-white">
                    <i class="bi bi-journal-check me-2"></i>Academic Access
                </div>
                <div class="card-body d-flex flex-wrap gap-3">
                    <a href="view_attendance.php" class="btn btn-primary quick-link">
                        <i class="bi bi-check2-square me-2"></i> View Attendance
                    </a>
                    <a href="view_results.php" class="btn btn-success quick-link">
                        <i class="bi bi-bar-chart-line me-2"></i> View Results
                    </a>
                    <a href="submit_assignment.php" class="btn btn-warning quick-link">
                        <i class="bi bi-upload me-2"></i> Submit Assignments
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Row 2: 3 Sections Side by Side -->
    <div class="row">
        <!-- My Subjects -->
        <div class="col-lg-4 mb-4">
            <div class="card h-100 shadow">
                <div class="card-header bg-info text-white">
                    <i class="bi bi-book me-2"></i>My Subjects
                </div>
                <div class="card-body">
                    <?php if ($subjects): ?>
                        <ul class="mb-0">
                            <?php foreach ($subjects as $sub): ?>
                                <li><?= htmlspecialchars($sub) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    <?php else: ?>
                        <p class="text-muted">No subjects found.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Upcoming Deadlines -->
        <div class="col-lg-4 mb-4">
            <div class="card h-100 shadow">
                <div class="card-header bg-warning text-dark">
                    <i class="bi bi-calendar2-event me-2"></i>Upcoming Deadlines
                </div>
                <div class="card-body">
                    <?php if ($deadlines): ?>
                        <ul class="mb-0">
                            <?php foreach ($deadlines as $dl): ?>
                                <li>
                                    <strong><?= htmlspecialchars($dl['title']) ?>:</strong>
                                    <span class="badge bg-primary"><?= date('d M Y, h:i A', strtotime($dl['deadline'])) ?></span>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php else: ?>
                        <p class="text-muted">No upcoming deadlines.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Support & Profile -->
        <div class="col-lg-4 mb-4">
            <div class="card h-100 shadow">
                <div class="card-header bg-secondary text-white">
                    <i class="bi bi-person-lines-fill me-2"></i>Support & Profile
                </div>
                <div class="card-body d-grid gap-3">
                    <a href="feedback.php" class="btn btn-info quick-link">
                        <i class="bi bi-chat-left-text me-2"></i> Send Feedback
                    </a>
                    <a href="profile.php" class="btn btn-dark quick-link">
                        <i class="bi bi-person-circle me-2"></i> View Profile
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
