<?php
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/db.php';
require_role('student');

$student_id = $_SESSION['user_id'];
$student_name = $_SESSION['full_name'];
$course = $_SESSION['course'];
$semester = $_SESSION['semester'];

// Fetch academic sessions
$sessions = $db->query("SELECT * FROM academic_sessions ORDER BY year_start DESC")->fetchAll();

// Filter by session
$session_id = $_GET['session_id'] ?? null;

$where = "WHERE r.student_id = ?";
$params = [$student_id];
if ($session_id) {
    $where .= " AND r.session_id = ?";
    $params[] = $session_id;
}

// Fetch results
$results_stmt = $db->prepare("SELECT r.*, s.subject_name, sess.name AS session_name
    FROM results r
    JOIN subjects s ON r.subject_id = s.id
    JOIN academic_sessions sess ON r.session_id = sess.id
    $where ORDER BY r.published_at DESC");
$results_stmt->execute($params);
$results = $results_stmt->fetchAll();

// Calculate summary
$total_subjects = count($results);
$total_marks = array_sum(array_column($results, 'marks'));
$average_marks = $total_subjects ? $total_marks / $total_subjects : 0;
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>View Results</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fc;
        }

        .dashboard-header {
            background: white;
            box-shadow: 0 0.15rem 1.75rem rgba(58, 59, 69, 0.15);
        }

        .card {
            border: none;
            box-shadow: 0 0.15rem 1.75rem rgba(58, 59, 69, 0.1);
            transition: transform 0.3s;
        }

        .card:hover {
            transform: translateY(-5px);
        }

        .highlight-today {
            background-color: #e0f0ff !important;
            font-weight: bold;
        }

        .fail-grade {
            color: #dc3545;
            font-weight: bold;
        }

        .topper {
            color: #28a745;
            font-weight: bold;
        }
    </style>
</head>

<body>
    <nav class="navbar navbar-expand-lg dashboard-header navbar-light mb-4">
        <div class="container-fluid">
            <span class="navbar-brand"><i class="bi bi-speedometer2 me-2"></i> Student Panel</span>
            <div class="d-flex align-items-center">
                <a href="dashboard.php" class="btn btn-outline-primary me-2"><i class="bi bi-arrow-left"></i> Back to
                    Dashboard</a>
                <span class="me-3 d-none d-sm-inline">
                    <i class="bi bi-person-circle me-1"></i> <?= htmlspecialchars($student_name) ?>
                </span>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="row mb-4">
            <div class="col-md-4 mb-3">
                <div class="card text-center p-3">
                    <h6 class="text-muted">Total Subjects</h6>
                    <h4><?= $total_subjects ?></h4>
                </div>
            </div>
            <div class="col-md-4 mb-3">
                <div class="card text-center p-3">
                    <h6 class="text-primary">Total Marks</h6>
                    <h4><?= number_format($total_marks, 2) ?></h4>
                </div>
            </div>
            <div class="col-md-4 mb-3">
                <div class="card text-center p-3">
                    <h6 class="text-success">Average Marks</h6>
                    <h4><?= number_format($average_marks, 2) ?></h4>
                </div>
            </div>
        </div>

        <div class="card shadow mb-4">
            <div class="card-header bg-primary text-white">
                <i class="bi bi-bar-chart-line me-2"></i> My Results
            </div>
            <div class="card-body">
                <form method="GET" class="row g-3 align-items-end mb-4">
                    <div class="col-md-10">
                        <label class="form-label">Filter by Session</label>
                        <select name="session_id" class="form-select">
                            <option value="">-- All Sessions --</option>
                            <?php foreach ($sessions as $sess): ?>
                                <option value="<?= $sess['id'] ?>" <?= $session_id == $sess['id'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($sess['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <button type="submit" class="btn btn-primary w-100"><i class="bi bi-filter-circle"></i>
                            Filter</button>
                    </div>
                </form>


                <!-- Course and Semester -->
                <div class="mb-3">
                    <p><strong>Course:</strong> <?= htmlspecialchars($course) ?></p>
                    <p><strong>Semester:</strong> <?= htmlspecialchars($semester) ?></p>
                </div>

                <?php if ($results): ?>
                    <div class="table-responsive">
                        <table class="table table-bordered align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th>Subject</th>
                                    <th>Session</th>
                                    <th>Marks</th>
                                    <th>Grade</th>
                                    <th>Published At</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $max_marks = max(array_column($results, 'marks'));
                                foreach ($results as $res):
                                    $is_today = (date('Y-m-d', strtotime($res['published_at'])) == date('Y-m-d'));
                                    ?>
                                    <tr class="<?= $is_today ? 'highlight-today' : '' ?>">
                                        <td><?= htmlspecialchars($res['subject_name']) ?></td>
                                        <td><?= htmlspecialchars($res['session_name']) ?></td>
                                        <td>
                                            <span class="<?= ($res['marks'] == $max_marks) ? 'topper' : '' ?>">
                                                <?= $res['marks'] ?>
                                            </span>
                                        </td>
                                        <td>
                                            <span class="<?= ($res['grade'] == 'F') ? 'fail-grade' : '' ?>">
                                                <?= htmlspecialchars($res['grade']) ?>
                                            </span>
                                        </td>
                                        <td><?= date('d M Y, h:i A', strtotime($res['published_at'])) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <p class="text-muted">No results found for the selected session.</p>
                <?php endif; ?>

            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>