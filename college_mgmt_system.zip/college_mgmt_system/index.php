<?php
session_start();
// --- Redirect logged-in users (no changes here) ---
if (isset($_SESSION['role'])) {
    switch ($_SESSION['role']) {
        case 'admin':
            header("Location: Admin/dashboard.php");
            exit;
        case 'staff':
            header("Location: Staff/dashboard.php");
            exit;
        case 'student':
            header("Location: Student/dashboard.php");
            exit;
    }
}
require_once __DIR__ . '/includes/db.php'; // Ensure db connection is established

// --- Fetch only courses (Subject fetching is removed) ---
$courses = []; // Initialize courses array
try {
    // Fetch necessary course details (added duration if available, you might need more)
    // If 'duration_years' is not in your courses table based on previous info, remove it from SELECT
    $stmt = $db->query("SELECT id, course_name, course_code, duration_years FROM courses ORDER BY course_name");
    if ($stmt) {
        $courses = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
} catch (PDOException $e) {
    // Basic error handling (log this error in a real application)
    error_log("Database Error: " . $e->getMessage());
    // Optionally display a user-friendly message, but avoid showing $e->getMessage() directly on a live site
    // echo "Error fetching course data. Please try again later.";
}

// --- Subject fetching PHP code has been REMOVED ---

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>College Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        /* --- Most CSS remains the same --- */
        body {
            font-family: 'Poppins', sans-serif;
            background: #f5f7fa;
            color: #333;
        }

        .navbar {
            background: #ffffff;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        }

        .navbar-brand {
            font-size: 1.8rem;
            font-weight: bold;
            color: #4a00e0;
        }

        .hero {
            padding: 100px 0;
            background: linear-gradient(to right, #4a00e0, #8e2de2);
            color: white;
            text-align: center;
            background-image: url('assets/hero_bg.jpg');
            /* Make sure this path is correct */
            background-size: cover;
            background-position: center;
            position: relative;
        }

        .hero::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.6);
        }

        .hero .container {
            position: relative;
            z-index: 2;
        }

        .hero h1 {
            font-size: 3rem;
            font-weight: 700;
        }

        .hero p {
            font-size: 1.2rem;
            margin-top: 15px;
        }

        .role-card {
            border: none;
            border-radius: 1rem;
            transition: transform 0.3s ease;
            background: #fff;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
            text-align: center;
            padding: 30px 20px;
        }

        .role-card:hover {
            transform: translateY(-8px);
        }

        .section-title {
            font-weight: 700;
            font-size: 2.5rem;
            margin-bottom: 30px;
            color: #4a00e0;
        }

        /* --- Modified Course Card styles for collapse trigger --- */
        /* .course-card .card-header {
            cursor: pointer;
            
            background-color: #fff;
            
            border-bottom: 1px solid rgba(0, 0, 0, .125);
            
            transition: background-color 0.2s ease-in-out;
        } */

        .course-card .card-header {
            cursor: pointer;
            background-color: #fff;
            border-bottom: 1px solid rgba(0, 0, 0, .125);
            transition: background-color 0.2s ease-in-out;
            display: flex;
            justify-content: center;
            /* Horizontally center the text */
            align-items: center;
            /* Vertically center the text */
            height: 100px;
            /* Ensure enough height for vertical centering */
            text-align: center;
            /* Text alignment */
        }


        .course-card .card-header:hover {
            background-color: #f8f9fa;
            /* Slight hover effect */
        }

        .course-card .card-body {
            padding-top: 1rem;
            /* Adjust padding for collapsed content */
        }

        .course-card {
            border: none;
            border-radius: 10px;
            overflow: hidden;
            /* Keep rounded corners */
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.06);
            /* Softer shadow */
            /* Remove hover transform if using header click */
        }

        /* --- Footer and other styles remain the same --- */
        footer {
            background: #f0f0f0;
            padding: 20px 0;
            text-align: center;
            font-size: 14px;
        }

        .footer-links a {
            margin: 0 10px;
            color: #555;
            text-decoration: none;
        }

        .footer-links a:hover {
            text-decoration: underline;
        }

        .btn-primary,
        .btn-success,
        .btn-warning {
            font-weight: 600;
        }

        /* Remove Subject list styling */
        /* .subject-list { ... } */
        /* .subject-list li { ... } */
    </style>
</head>

<body>

    <nav class="navbar navbar-expand-lg navbar-light sticky-top">
        <div class="container">
            <a class="navbar-brand" href="#"><i class="bi bi-mortarboard-fill me-2"></i>CollegeMS</a>
            <div>
                <a class="btn btn-outline-secondary me-2" href="#about">About</a>
                <a class="btn btn-outline-secondary me-2" href="#courses">Courses</a>
                <a class="btn btn-outline-secondary me-3" href="#contact">Contact</a>
                <a href="auth/login.php" class="btn btn-primary">
                    <i class="bi bi-box-arrow-in-right"></i> Login
                </a>
            </div>
        </div>
    </nav>

    <section class="hero d-flex align-items-center">
        <div class="container">
            <h1 class="display-4 fw-bold mb-3">Empowering Education</h1>
            <p class="lead mb-4">Manage Students, Faculty, Attendance, Assignments, and More Effortlessly!</p>
            <div class="row justify-content-center">
                <div class="col-md-3 mb-3 mb-md-0">
                    <div class="role-card">
                        <h5 class="card-title text-primary"><i class="bi bi-person-badge-fill me-2"></i>Admin Login</h5>
                        <a href="auth/login.php?role=admin" class="btn btn-primary w-100 mt-3">Admin Panel</a>
                    </div>
                </div>
                <div class="col-md-3 mb-3 mb-md-0">
                    <div class="role-card">
                        <h5 class="card-title text-success"><i class="bi bi-person-video3 me-2"></i>Faculty Login</h5>
                        <a href="auth/login.php?role=staff" class="btn btn-success w-100 mt-3">Faculty Panel</a>
                    </div>
                </div>
                <div class="col-md-3 mb-3 mb-md-0">
                    <div class="role-card">
                        <h5 class="card-title text-warning"><i class="bi bi-person-fill me-2"></i>Student Login</h5>
                        <a href="auth/login.php?role=student" class="btn btn-warning w-100 mt-3">Student Panel</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="container my-5" id="courses"
        style="background: url('assets/course_default.jpg'); background-size: cover; background-position: center; color: white; ">
        <h2
            style="font-weight: 700; font-size: 2.5rem; margin-bottom: 30px; color:rgb(255, 255, 255); text-align: center;">
            Courses Offered</h2>
        <div class="row">
            <?php if (!empty($courses)): ?>
                <?php foreach ($courses as $course): ?>
                    <div class="col-md-4 mb-4">
                        <div class="card course-card">
                            <!-- <img src="assets/course_default.jpg" class="card-img-top" alt="Course Image"> -->

                            <div class="card-header" data-bs-toggle="collapse"
                                data-bs-target="#collapseCourse<?= $course['id'] ?>" aria-expanded="false"
                                aria-controls="collapseCourse<?= $course['id'] ?>">
                                <h5 class="card-title text-primary mb-0"><?= htmlspecialchars($course['course_name']) ?></h5>
                            </div>

                            <div id="collapseCourse<?= $course['id'] ?>" class="collapse">
                                <div class="card-body">
                                    <p class="card-text mb-1">
                                        <strong>Code:</strong> <?= htmlspecialchars($course['course_code']) ?>
                                    </p>
                                    <?php if (isset($course['duration_years'])): ?>
                                        <p class="card-text mb-1">
                                            <strong>Duration:</strong> <?= htmlspecialchars($course['duration_years']) ?> Year(s)
                                        </p>
                                    <?php endif; ?>
                                    <?php
                                    // Determine description based on course name
                                    $description = '';
                                    switch (strtolower($course['course_name'])) {
                                        case 'bca':
                                            $description = "BCA (Bachelor of Computer Applications) is a three-year undergraduate program focusing on computer fundamentals, programming, web development, databases, and IT systems. It prepares students for careers in IT and software industries.";
                                            break;
                                        case 'bba':
                                            $description = "BBA (Bachelor of Business Administration) is a three-year undergraduate course that provides knowledge in business management, marketing, finance, and entrepreneurship, building leadership and administrative skills.";
                                            break;
                                        case 'msc it':
                                        case 'msc in information technology':
                                            $description = "MSc IT (Master of Science in Information Technology) is a two-year postgraduate program emphasizing advanced studies in programming, database management, networking, cybersecurity, and cloud computing.";
                                            break;
                                        default:
                                            $description = "This course provides specialized education to equip students with essential knowledge and skills for their career development.";
                                            break;
                                    }
                                    ?>
                                    <p class="card-text text-muted small mt-2"><?= htmlspecialchars($description) ?></p>

                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="col-12">
                    <p class="text-center text-muted">No courses are currently available.</p>
                </div>
            <?php endif; ?>
        </div>
    </section>


    <section id="about" class="container my-5">
        <h2 class="section-title text-center">About Us</h2>
        <p class="text-center">
            Welcome to our College Management System! Here, we streamline and manage all aspects of education, including
            student registrations, course management, attendance tracking, and more. Our system is designed to help
            educators and students alike achieve their goals.
        </p>
    </section>


    <section class="container my-5" id="contact">
        <h2 class="section-title text-center">Get in Touch</h2>
        <div class="row justify-content-center">
            <div class="col-md-6">
                <form>
                    <div class="mb-3">
                        <label class="form-label">Your Name</label>
                        <input type="text" class="form-control" placeholder="John Doe">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Email Address</label>
                        <input type="email" class="form-control" placeholder="name@example.com">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Your Message</label>
                        <textarea class="form-control" rows="4" placeholder="How can we help you?"></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Send Message</button>
                </form>
            </div>
        </div>
    </section>

    <footer class="mt-5">
        <div class="footer-links mb-2">
            <a href="#about">About</a>
            <a href="#courses">Courses</a>
            <a href="#contact">Contact</a>
        </div>
        <small class="text-muted">&copy; <?= date('Y') ?> CollegeMS. All Rights Reserved.</small>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>